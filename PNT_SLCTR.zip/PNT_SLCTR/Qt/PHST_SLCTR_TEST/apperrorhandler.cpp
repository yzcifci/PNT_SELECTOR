#include "apperrorhandler.h"



void appError(uint16_t errorIndex)
{
    switch (errorIndex)
    {
    case WRONG_COM_RX_LENGTH_ERROR:
        break;
    default:
        break;
    }
}
