#ifndef APPERRORHANDLER_H
#define APPERRORHANDLER_H

#include "qglobal.h"

enum
{
    WRONG_COM_RX_LENGTH_ERROR,
};

void appError(uint16_t errorIndex);
#endif // APPERRORHANDLER_H
