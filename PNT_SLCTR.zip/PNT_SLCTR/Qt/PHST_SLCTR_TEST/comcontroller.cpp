
#include "comcontroller.h"
#include "qglobal.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"
#include "apperrorhandler.h"
#include <QDebug>

comClass_ comm;

void comClass_::comRecevieControlTask()
{
    static uint8_t array8[4];
    static uint16_t cnt32 = 0;
    static uint16_t cnt16 = 0;



    while(tail < comRxBuff.size())
    {
        if(comState == COM_HANDLE) return;
        switch(comState)
        {
        case COM_START:
            array8[0] = array8[1];
            array8[1] = array8[2];
            array8[2] = array8[3];
            array8[3] = comRxBuff.at(tail);

            if(array8[0] == (uint8_t)(COMMAND_START & 0x000000FF) &&
                    array8[1] == (uint8_t)((COMMAND_START >> 8) & 0x000000FF) &&
                    array8[2] == (uint8_t)((COMMAND_START >> 16) & 0x000000FF) &&
                    array8[3] == (uint8_t)((COMMAND_START >> 24) & 0x000000FF))
            {
                comState = COM_COMMAND;
                partialLength = 0;
                partialLengthCntr = 0;
                totalLength = 0;
                command = COMMAND_NONE;
                cnt32 = 0;
            }
            else if((array8[0] == 'l') && (array8[1] == 'o') && (array8[2] == 'o') && (array8[3] == 'p'))
            {

            }

            break;
        case COM_COMMAND:
            comm.command = comRxBuff.at(tail);
            comState = COM_DATA_LENGTH;
            break;
        case COM_DATA_LENGTH:
        {
            static union32 datalengthUni32;
            datalengthUni32.array[cnt32++] = comRxBuff.at(tail);
            if(cnt32 >= 4)
            {
                comState = COM_PARTIAL_DATA_LENGTH;
                totalLength = datalengthUni32.data;
                cnt32 = 0;
            }
            break;
        }

        case COM_PARTIAL_DATA_LENGTH:
        {
            static union16 datalengthUni16;
            datalengthUni16.array[cnt16++] = comRxBuff.at(tail);
            if(cnt16 >= 2)
            {
                comState = COM_DATA;
                partialLength = datalengthUni16.data;
                cnt16 = 0;
                if(partialLength == 0)
                {
                    comState = COM_HANDLE;
                }
            }
        }

            break;
        case COM_DATA:
            if(partialLengthCntr < partialLength)
            {
                commandData.append(comRxBuff.at(tail));
                partialLengthCntr++;

            }

            if(partialLengthCntr == partialLength)
            {
                comState = COM_HANDLE;
                qDebug()<<" COM_HANDLE";
                comm.totalLengthCntr += partialLength;
                qDebug()<<" totalLengthCntr:"<<comm.totalLengthCntr;
            }

            if((partialLengthCntr > partialLength) || (partialLength > totalLength) || (totalLengthCntr > totalLength))
            {
                appError(WRONG_COM_RX_LENGTH_ERROR);
                qDebug()<<" totalLengthCntr:"<<comm.totalLengthCntr;
            }
            break;

        default:

            break;
        }
        tail++;
//            qDebug()<<" totalLengthCntr:"<<comm.totalLengthCntr<<", partialLengthCntr:"<<comm.partialLengthCntr;
//            qDebug()<<" totalLength:"<<comm.totalLength<<", partialLength:"<<comm.partialLength;
//            qDebug()<<" size:"<<comm.comRxBuff.size()<<", tail:"<<tail;
//            qDebug()<<" comState:"<<comState;
//            qDebug()<<"-----------------------------------------------------------";
    }


}


