#ifndef COMCONTROLLER_H
#define COMCONTROLLER_H

#include "qglobal.h"
#include "qbytearray.h"

#define COMMAND_START		0x23469198
#define COMMAND_BUFFER_SIZE		256


enum
{
    COM_START,
    COM_COMMAND,
    COM_DATA_LENGTH,
    COM_PARTIAL_DATA_LENGTH,
    COM_DATA,
    COM_HANDLE,


};

enum
{
    COMMAND_NONE,
    COMMAND_WRITE_REG,
    COMMAND_READ_REG,
    COMMAND_SET_PARAMETER,
    COMMAND_GET_IMAGE,
    COMMAND_ACK,


};






typedef union
{
    uint32_t data;
    uint8_t array[4];
}union32;

typedef union
{
    uint16_t data;
    uint8_t array[2];
}union16;


class comClass_
{
public:
    QByteArray comRxBuff;
    uint32_t tail               = 0;
    uint8_t comState 			= 0;
    uint32_t totalLength 		= 0;
    uint32_t totalLengthCntr	= 0;
    uint16_t partialLength      = 0;
    uint16_t partialLengthCntr  = 0;
    uint8_t ackTrig             = 0;
    uint8_t command		 		= 0;
    QByteArray commandData;
    uint8_t comStatus           = 0;


    void comRecevieControlTask();


};

extern comClass_ comm;
#endif // COMCONTROLLER_H
