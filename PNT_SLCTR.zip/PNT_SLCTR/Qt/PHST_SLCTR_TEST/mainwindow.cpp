#include "mainwindow.h"
#include "ui_mainwindow.h"
#include <QtSerialPort/QSerialPortInfo>
#include <QIntValidator>
#include <QLineEdit>
#include <QSerialPort>
#include <QMessageBox>
#include <QLabel>
#include <QtSerialPort/QSerialPort>
#include <QPainter>
#include <QDebug>
#include <QTimer>
#include <QFont>
#include "comcontroller.h"
#include "telemetry.h"
#include "QGridLayout.h"
#include "QImageReader"
#include <QImage>
#include <QFileDialog>
#include <QtGui>
#include <qmath.h>
#include <apperrorhandler.h>

#define IO_BUTTON_STARTX    540
#define IO_BUTTON_STARTY    30

QString selectStyle = "background-color: rgb(150, 150, 150);";
QString defStyle = "background-color: rgb(225, 225, 225);";
QFont font1;
QTimer *timer;
QSerialPort serial;
app_ app;
QPushButton *buttonA[23];
QPushButton *buttonB[23];
QImage image;

uint32_t buttonApos[23][2] =
{
    IO_BUTTON_STARTX, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 100, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 200, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 300, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 400, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 500, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 600, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 700, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 800, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 900, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 1000, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX + 1100, IO_BUTTON_STARTY,
    IO_BUTTON_STARTX       , IO_BUTTON_STARTY + 70,
    IO_BUTTON_STARTX + 100, IO_BUTTON_STARTY+ 70,
    IO_BUTTON_STARTX + 200, IO_BUTTON_STARTY+ 70,
    IO_BUTTON_STARTX + 300, IO_BUTTON_STARTY+ 70,
    IO_BUTTON_STARTX + 400, IO_BUTTON_STARTY+ 70,
    IO_BUTTON_STARTX + 500, IO_BUTTON_STARTY+ 70,
    IO_BUTTON_STARTX + 600, IO_BUTTON_STARTY+ 70,
    IO_BUTTON_STARTX + 700, IO_BUTTON_STARTY+ 70,
    IO_BUTTON_STARTX + 800, IO_BUTTON_STARTY+ 70,
    IO_BUTTON_STARTX + 900, IO_BUTTON_STARTY+ 70,
    IO_BUTTON_STARTX + 1000, IO_BUTTON_STARTY+ 70,

};
uint32_t buttonBpos[23][2] =
{
    IO_BUTTON_STARTX, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 100, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 200, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 300, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 400, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 500, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 600, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 700, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 800, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 900, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 1000, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX + 1100, IO_BUTTON_STARTY + 140,
    IO_BUTTON_STARTX, IO_BUTTON_STARTY + 140 + 70,
    IO_BUTTON_STARTX + 100, IO_BUTTON_STARTY + 140+ 70,
    IO_BUTTON_STARTX + 200, IO_BUTTON_STARTY + 140+ 70,
    IO_BUTTON_STARTX + 300, IO_BUTTON_STARTY + 140+ 70,
    IO_BUTTON_STARTX + 400, IO_BUTTON_STARTY + 140+ 70,
    IO_BUTTON_STARTX + 500, IO_BUTTON_STARTY + 140+ 70,
    IO_BUTTON_STARTX + 600, IO_BUTTON_STARTY + 140+ 70,
    IO_BUTTON_STARTX + 700, IO_BUTTON_STARTY + 140+ 70,
    IO_BUTTON_STARTX + 800, IO_BUTTON_STARTY + 140+ 70,
    IO_BUTTON_STARTX + 900, IO_BUTTON_STARTY + 140+ 70,
    IO_BUTTON_STARTX + 1000, IO_BUTTON_STARTY + 140+ 70,

};

void buttonClickCallAport(uint16_t index);
void buttonClickCallBport(uint16_t index);
uint16_t getButtonItemIndexA(uint16_t x, uint16_t y);
uint16_t getButtonItemIndexB(uint16_t x, uint16_t y);

MainWindow::MainWindow(QWidget *parent) :
    QMainWindow(parent),
    ui(new Ui::MainWindow)
{
    QApplication::setAttribute(Qt::AA_EnableHighDpiScaling);
    ui->setupUi(this);
    this->showPorts();
    QObject::connect(&serial, &QSerialPort::readyRead, this, &MainWindow::readData);
    timer = new QTimer(this);
    connect(timer, SIGNAL(timeout()), this, SLOT(updateTimerTimeout()));
    timer->start(50);
    ui->IOcombo->addItem(QStringLiteral("TOGGLE"), IO_DRIVE_TOGGLE);
    ui->IOcombo->addItem(QStringLiteral("PULSE"), IO_DRIVE_PULSE);
    ui->IOcombo->addItem(QStringLiteral("BULK"), IO_DRIVE_BULK);
    font1.setPointSize(8);
    for(uint32_t i = 0; i<23; i++)
    {
        buttonA[i] = new QPushButton(this);
        buttonA[i]->setText("A"+QString::number(i+1));
        connect(buttonA[i], SIGNAL(clicked(bool)), this, SLOT(onClickedA(bool)));
        layout()->addWidget(buttonA[i]); // Add the button to the layout
        buttonA[i]->move(buttonApos[i][0], buttonApos[i][1]);
        buttonA[i]->resize(80,50);
        buttonA[i]->show();
    }
    for(uint32_t i = 0; i<23; i++)
    {
        buttonB[i] = new QPushButton(this);
        buttonB[i]->setText("B"+QString::number(i+1));
        connect(buttonB[i], SIGNAL(clicked(bool)), this, SLOT(onClickedB(bool)));
        layout()->addWidget(buttonB[i]); // Add the button to the layout
        buttonB[i]->move(buttonBpos[i][0], buttonBpos[i][1]);
        buttonB[i]->resize(80,50);
        buttonB[i]->show();
    }
    ui->imgLoadCombo->addItem(QStringLiteral("COMPUTER"), IMG_LOAD_FROM_COMPUTER);
    ui->imgLoadCombo->addItem(QStringLiteral("DEV CAP"), IMG_LOAD_FROM_DEVICE);
    ui->imgLoadCombo->addItem(QStringLiteral("SAVE PNG"), IMG_SAVE_PNG);
    ui->imgLoadCombo->addItem(QStringLiteral("SAVE TXT"), IMG_SAVE_TXT);
    ui->camCombo->addItem(QStringLiteral("CAM1"), CAMERA1);
    ui->camCombo->addItem(QStringLiteral("CAM2"), CAMERA2);

}
MainWindow::~MainWindow()
{
    delete ui;
}


void MainWindow::updateTimerTimeout()
{
    timer->stop();
    this->showPorts();
    app.ioDriveMode = ui->IOcombo->itemData(ui->IOcombo->currentIndex()).toInt();
    IOreadWriteControlTask();
    timer->start(TIMER_PERIOD);
    comm.comRecevieControlTask();
    commExecuter();

    {
        static uint32_t timeCntr = 0;
        timeCntr += TIMER_PERIOD;
        if(timeCntr >= 100)
        {
            timeCntr = 0;
            app.updateScreen = 1;
            MainWindow::update();
        }
    }
}

void MainWindow::paintEvent(QPaintEvent *event)
{
    uint8_t r,g,b;
    uint16_t data1,data2;
    rgb565map rgbData;
    if(app.updateScreen == 0)return;
    QPainter painter(this);
    for(quint32 y=0;y<IMG_SIZEY;y++)
    {
        for(quint32 x=0;x<IMG_SIZEX;x++)
        {
            data1 = app.imgBuffer[(((y * IMG_SIZEX) + x) * 2)];
            data2 = app.imgBuffer[(((y * IMG_SIZEX) + x) * 2) + 1];
            rgbData.data16 = (data1 | ((data2 << 8) & 0xFF00));
            r = (uint8_t)rgbData.rgb.red << 3;
            g = (uint8_t)rgbData.rgb.green << 2;
            b = (uint8_t)rgbData.rgb.blue << 3;
            QPen myPen(QColor(r,g,b), 1, Qt::SolidLine);
            painter.setPen(myPen);
            painter.drawPoint(500+x,500+y);
        }
    }
    app.updateScreen=0;
}
void MainWindow::showPorts()
{
    ui->serialCombo->clear();
    const auto infos = QSerialPortInfo::availablePorts();
    for (const QSerialPortInfo &info : infos)
    {
        QString portName=info.portName();
        ui->serialCombo->addItem(portName);
    }
}

void MainWindow::on_openButton_clicked()
{
    QString portName=ui->serialCombo->currentText();

    serial.setPortName(portName);
    serial.setBaudRate(960000);

    if(serial.open(QIODevice::ReadWrite))
    {
        ui->textEdit->setText(portName + " Serial Port Opened");
    }
    else
    {
        ui->textEdit->setText("Serial Port Open Error");
    }

    qDebug()<<"open";
}

void MainWindow::commExecuter()
{
    if(comm.comState == COM_HANDLE)
    {
        if((comm.partialLength == comm.totalLength) || (comm.totalLength == comm.totalLengthCntr) )
        {
            switch(comm.command)
            {
            case COMMAND_READ_REG:
                ui->textEdit->append("Reg " + QString::number(app.readRegRequest) + ": " + QString::number(comm.commandData[0]));
                break;

            case COMMAND_GET_IMAGE:
                for(uint32_t i = 0; i< (uint32_t)comm.commandData.size(); i++)
                {
                    app.imgBuffer[i] = comm.commandData.at(i);
                }
                break;

            }
            comm.totalLengthCntr = 0;
            comm.commandData.clear();

        }
        else if(comm.partialLength < comm.totalLength)
        {
            uint32_t i = 0;
            char writeData[32];
            union32 comstart;
            union32 totalDataLength ;
            union16 partialDataLength ;
            comstart.data               = COMMAND_START;
            totalDataLength.data        = 0;
            partialDataLength.data      = 0;
            writeData[i++] = comstart.array[0];
            writeData[i++] = comstart.array[1];
            writeData[i++] = comstart.array[2];
            writeData[i++] = comstart.array[3];
            writeData[i++] = COMMAND_ACK;
            writeData[i++] = totalDataLength.array[0];
            writeData[i++] = totalDataLength.array[1];
            writeData[i++] = totalDataLength.array[2];
            writeData[i++] = totalDataLength.array[3];
            writeData[i++] = partialDataLength.array[0];
            writeData[i++] = partialDataLength.array[1];
            serial.write((const char*)writeData, i);
        }
        else
        {
            appError(WRONG_COM_RX_LENGTH_ERROR);
        }
        comm.comState = COM_START;
        comm.comRxBuff.clear();
        comm.tail = 0;
        ui->textEdit->setText("received: " + QString::number(comm.totalLengthCntr) + "/" + QString::number(comm.totalLength));
    }
}
void MainWindow::readData()
{
    QByteArray rxData;
    rxData = serial.readAll();
    comm.comRxBuff.append(rxData);

    uint32_t rxSize = comm.comRxBuff.size();
    if(rxSize >= 4)
    {
        if((comm.comRxBuff.at(rxSize - 4) == 'l') && (comm.comRxBuff.at(rxSize - 3) == 'o') && (comm.comRxBuff.at(rxSize - 2) == 'o') && (comm.comRxBuff.at(rxSize - 1) == 'p'))
        {
            ui->textEdit->append(comm.comRxBuff);
            comm.comRxBuff.clear();
        }
    }
}


void MainWindow::on_loopTest_clicked()
{
    serial.write("loop", 4);
}

void MainWindow::on_closeButton_clicked()
{
    serial.close();
    ui->textEdit->setText("port closed");
}

void MainWindow::on_camLed_clicked()
{
    QString stringDat;
    bool bStatus;
    uint32_t val;
    stringDat = ui->camLedText->text();
    val = stringDat.toFloat(&bStatus);
    setParameterSend(P_CAM_LED_PWM, val);
}

void MainWindow::on_mot1Speed_clicked()
{
    QString stringDat;
    bool bStatus;
    uint32_t val;
    stringDat = ui->mot1SpeedText->text();
    val = stringDat.toFloat(&bStatus);
    setParameterSend(P_MOTOR1_SPEED_SET, val);
}

void MainWindow::on_mot2Speed_clicked()
{
    QString stringDat;
    bool bStatus;
    uint32_t val;
    stringDat = ui->mot2SpeedText->text();
    val = stringDat.toFloat(&bStatus);
    setParameterSend(P_MOTOR2_SPEED_SET, val);
}

void MainWindow::on_regReadButton_clicked()
{
    QString stringDat;
    bool bStatus;
    stringDat = ui->regReadText->text();
    app.readRegRequest = stringDat.toInt(&bStatus);

    uint32_t i = 0;
    char writeData[32];
    uint8_t camNo = ui->camCombo->itemData(ui->IOcombo->currentIndex()).toInt();
    union32 comstart;
    union32 totalDataLength ;
    union16 partialDataLength ;

    comstart.data               = COMMAND_START;
    totalDataLength.data        = 2;
    partialDataLength.data      = 2;
    writeData[i++] = comstart.array[0];
    writeData[i++] = comstart.array[1];
    writeData[i++] = comstart.array[2];
    writeData[i++] = comstart.array[3];
    writeData[i++] = COMMAND_READ_REG;
    writeData[i++] = totalDataLength.array[0];
    writeData[i++] = totalDataLength.array[1];
    writeData[i++] = totalDataLength.array[2];
    writeData[i++] = totalDataLength.array[3];
    writeData[i++] = partialDataLength.array[0];
    writeData[i++] = partialDataLength.array[1];
    writeData[i++] = camNo;
    writeData[i++] = app.readRegRequest;
    serial.write((const char*)writeData, i);
}
void MainWindow::on_imgAction_clicked()
{
    uint8_t loadMode = 0;
    loadMode = ui->imgLoadCombo->itemData(ui->imgLoadCombo->currentIndex()).toInt();
    switch(loadMode)
    {
    case IMG_LOAD_FROM_COMPUTER:
    {
        uint16_t red5;
        uint16_t green6;
        uint16_t blue5;
        uint16_t pixelData;
        QColor rgbData;
        uint32_t imgCntr = 0;
        QString fileName = QFileDialog::getOpenFileName(this,  tr("Open Image"), "C:/Users/yzcifci/Desktop/", tr("Image Files (*.png *.jpg *.bmp)"));
        image.load(fileName);
        qDebug()<<"width"<<image.width()<<"height"<<image.height();
        if(image.width() == IMG_SIZEX || image.height() == IMG_SIZEY)
        {
            for(uint32_t j=0; j<IMG_SIZEY;j++)
            {
                for(uint32_t i=0;i<IMG_SIZEX;i++)
                {
                    rgbData = image.pixelColor(i,j);
                    red5    = ((rgbData.red() & 0x00F8)>>3);
                    green6  = ((rgbData.green() & 0x00FC)>>2);
                    blue5   = ((rgbData.blue() & 0x00F8)>>3);
                    pixelData = ((blue5<<11) & 0xF800)  | ((green6<<5) & 0x07E0) | (red5 & 0x001F);
                    app.imgBuffer[imgCntr] = (char)(pixelData & 0x00FF);
                    app.imgBuffer[imgCntr+1] = (char)((pixelData >> 8) & 0x00FF);
                    imgCntr+=2;
                }
            }
        }
        else
        {
            ui->textEdit->append("wrong image size load error!");
        }
    }
        break;

    case IMG_LOAD_FROM_DEVICE:
    {
        uint32_t i = 0;
        char writeData[32];
        union32 comstart;
        union32 totalDataLength ;
        union16 partialDataLength ;
        comstart.data               = COMMAND_START;
        totalDataLength.data        = 0;
        partialDataLength.data      = 0;
        writeData[i++] = comstart.array[0];
        writeData[i++] = comstart.array[1];
        writeData[i++] = comstart.array[2];
        writeData[i++] = comstart.array[3];
        writeData[i++] = COMMAND_GET_IMAGE;
        writeData[i++] = totalDataLength.array[0];
        writeData[i++] = totalDataLength.array[1];
        writeData[i++] = totalDataLength.array[2];
        writeData[i++] = totalDataLength.array[3];
        writeData[i++] = partialDataLength.array[0];
        writeData[i++] = partialDataLength.array[1];
        serial.write((const char*)writeData, i);
    }
        break;

    case IMG_SAVE_PNG:
    {
        QByteArray imageData;
        uint8_t r,g,b;
        uint16_t data1,data2;
        rgb565map rgbData;
        QString filename;
        for(uint32_t y=0; y<IMG_SIZEY; y++)
        {
            for(uint32_t x=0; x<IMG_SIZEX; x++)
            {
                data1 = app.imgBuffer[(((y * IMG_SIZEX) + x) * 2)];
                data2 = app.imgBuffer[(((y * IMG_SIZEX) + x) * 2) + 1];
                rgbData.data16 = (data1 | ((data2 << 8) & 0xFF00));
                r = (uint8_t)rgbData.rgb.red << 3;
                g = (uint8_t)rgbData.rgb.green << 2;
                b = (uint8_t)rgbData.rgb.blue << 3;
                imageData.append(r);
                imageData.append(g);
                imageData.append(b);
            }
        }
        QImage *image =new QImage((const uchar*)imageData.constData(),IMG_SIZEX, IMG_SIZEY,QImage::Format_RGB888);
        filename = QFileDialog::getSaveFileName(this, "Save file", "", "*.png");
        if (!image->save(filename, "PNG"))
        {
            ui->textEdit->append("could'nt save image");
        }
    }
        break;

    case IMG_SAVE_TXT:
    {
        QString filename;
        filename = QFileDialog::getSaveFileName(this, "Save file", "", "*.txt");
        QFile file_s(filename);
        QTextStream stream(&file_s);
        if(file_s.open(QFile::WriteOnly))
        {
            for(uint32_t i=0; i<sizeof(app.imgBuffer); i++)
            {
                stream<<"0x"<< QString::number(app.imgBuffer[i], 16)<<", ";
                if((i % 100) == 0)
                {
                    stream<<"\r\n";
                }
            }
        }
    }
        break;

    }
}
void setParameterSend(uint16_t pindex, uint32_t val)
{
    static char writeData[64];
    uint32_t i = 0;
    union32 comstart;
    union32 totalDataLength ;
    union16 partialDataLength ;
    union16 paramIindex;
    union32 data;

    comstart.data               = COMMAND_START;
    totalDataLength.data        = 6;
    partialDataLength.data      = 6;
    paramIindex.data            = pindex;
    data.data                   = val;

    writeData[i++] = comstart.array[0];
    writeData[i++] = comstart.array[1];
    writeData[i++] = comstart.array[2];
    writeData[i++] = comstart.array[3];
    writeData[i++] = COMMAND_SET_PARAMETER;
    writeData[i++] = totalDataLength.array[0];
    writeData[i++] = totalDataLength.array[1];
    writeData[i++] = totalDataLength.array[2];
    writeData[i++] = totalDataLength.array[3];
    writeData[i++] = partialDataLength.array[0];
    writeData[i++] = partialDataLength.array[1];
    writeData[i++] = paramIindex.array[0];
    writeData[i++] = paramIindex.array[1];
    writeData[i++] = data.array[0];
    writeData[i++] = data.array[1];
    writeData[i++] = data.array[2];
    writeData[i++] = data.array[3];
    serial.write((const char*)writeData, i);
}



void MainWindow::onClickedA(bool state)
{
    static uint16_t index =0;

    QPushButton *button = qobject_cast<QPushButton *>(sender());
    index = getButtonItemIndexA(button->pos().x(),  button->pos().y());
    buttonClickCallAport(index);

    qDebug()<<"A"<<index;

}

void MainWindow::onClickedB(bool state)
{
    static uint16_t index =0;

    QPushButton *button = qobject_cast<QPushButton *>(sender());
    index = getButtonItemIndexB(button->pos().x(),  button->pos().y());
    buttonClickCallBport(index);

    qDebug()<<"B"<<index;
}

void buttonClickCallAport(uint16_t index)
{
    if(app.Aport[index] != 0)
    {
        buttonA[index]->setStyleSheet(defStyle);
        app.Aport[index] = 0;
    }
    else
    {
        buttonA[index]->setStyleSheet(selectStyle);
        app.Aport[index] = 1;
    }
    buttonA[index]->setFont(font1);
}

void buttonClickCallBport(uint16_t index)
{
    if(app.Bport[index] != 0)
    {
        buttonB[index]->setStyleSheet(defStyle);
        app.Bport[index] = 0;
    }
    else
    {
        buttonB[index]->setStyleSheet(selectStyle);
        app.Bport[index] = 1;
    }
    buttonB[index]->setFont(font1);
}

uint16_t getButtonItemIndexA(uint16_t x, uint16_t y)
{
    for(uint32_t i=0; i<23; i++)
    {
        if((x == buttonApos[i][0]) && (y == buttonApos[i][1]))
        {
            return i;
        }
    }
    return 0;
}

uint16_t getButtonItemIndexB(uint16_t x, uint16_t y)
{
    for(uint32_t i=0; i<23; i++)
    {
        if((x == buttonBpos[i][0]) && (y == buttonBpos[i][1]))
        {
            return i;
        }
    }
    return 0;
}



void MainWindow::on_textClear_clicked()
{
    ui->textEdit->clear();
}

void MainWindow::on_writeRegButton_clicked()
{
    bool bStatus;
    uint32_t i = 0;
    uint8_t reg, val;
    reg = ui->writeRegTxt->text().toInt(&bStatus);
    val = ui->writeRegVal->text().toInt(&bStatus);
    uint8_t camNo = ui->camCombo->itemData(ui->IOcombo->currentIndex()).toInt();

    char writeData[32];
    union32 comstart;
    union32 totalDataLength ;
    union16 partialDataLength ;

    comstart.data               = COMMAND_START;
    totalDataLength.data        = 3;
    partialDataLength.data      = 3;
    writeData[i++] = comstart.array[0];
    writeData[i++] = comstart.array[1];
    writeData[i++] = comstart.array[2];
    writeData[i++] = comstart.array[3];
    writeData[i++] = COMMAND_WRITE_REG;
    writeData[i++] = totalDataLength.array[0];
    writeData[i++] = totalDataLength.array[1];
    writeData[i++] = totalDataLength.array[2];
    writeData[i++] = totalDataLength.array[3];
    writeData[i++] = partialDataLength.array[0];
    writeData[i++] = partialDataLength.array[1];
    writeData[i++] = camNo;
    writeData[i++] = reg;
    writeData[i++] = val;
    serial.write((const char*)writeData, i);

}
