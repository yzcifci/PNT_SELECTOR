#ifndef MAINWINDOW_H
#define MAINWINDOW_H

#include <QMainWindow>
#include <QSerialPort>
#include <QThread>

#define TIMER_PERIOD 20
#define IO_PULSE_PERIOD 100
#define IMG_SIZEX   800
#define IMG_SIZEY   100

enum
{
    P_A1                 ,
    P_A2                 ,
    P_A3                 ,
    P_A4                 ,
    P_A5                 ,
    P_A6                 ,
    P_A7                 ,
    P_A8                 ,
    P_A9                 ,
    P_A10                ,
    P_A11                ,
    P_A12                ,
    P_A13                ,
    P_A14                ,
    P_A15                ,
    P_A16                ,
    P_A17                ,
    P_A18                ,
    P_A19                ,
    P_A20                ,
    P_A21                ,
    P_A22                ,
    P_A23                ,
    P_B1                 ,
    P_B2                 ,
    P_B3                 ,
    P_B4                 ,
    P_B5                 ,
    P_B6                 ,
    P_B7                 ,
    P_B8                 ,
    P_B9                 ,
    P_B10                ,
    P_B11                ,
    P_B12                ,
    P_B13                ,
    P_B14                ,
    P_B15                ,
    P_B16                ,
    P_B17                ,
    P_B18                ,
    P_B19                ,
    P_B20                ,
    P_B21                ,
    P_B22                ,
    P_B23                ,
    P_MOTOR1_SPEED_SET     ,
    P_MOTOR2_SPEED_SET     ,
    P_MOTOR1_ACC_SET       ,
    P_MOTOR2_ACC_SET       ,
    P_CAM_LED_PWM          ,

    P_TOTAL
};
enum
{
    IO_DRIVE_TOGGLE,
    IO_DRIVE_PULSE,
    IO_DRIVE_BULK
};
enum
{
    IMG_LOAD_FROM_COMPUTER,
    IMG_LOAD_FROM_DEVICE,
    IMG_SAVE_PNG,
    IMG_SAVE_TXT,
};
enum
{
    CAMERA1,
    CAMERA2
};
union rgb565map
{
    uint16_t data16;
    struct
    {
        uint16_t red:5;
        uint16_t green:6;
        uint16_t blue:5;
    }rgb;
};
class app_
{
public:
    uint8_t Aport[23];
    uint8_t Bport[23];
    uint8_t AportClickCall[23];
    uint8_t BportCliclCall[23];
    uint8_t ioDriveMode;
    uint8_t readRegRequest = 0;
    uint8_t updateScreen = 0;
    uint8_t imgBuffer[IMG_SIZEX * IMG_SIZEY *2];

};

extern app_ app;
extern QSerialPort serial;

namespace Ui
{
class MainWindow;
}

class MainWindow : public QMainWindow
{
    Q_OBJECT

public:
    explicit MainWindow(QWidget *parent = 0);
    ~MainWindow();
    void showPorts();
    void openSerialPort();
    void readData();
    void commExecuter();
private slots:
    void paintEvent(QPaintEvent *event);
    void updateTimerTimeout();
    void on_closeButton_clicked();
    void on_loopTest_clicked();
    void onClickedA(bool state);
    void onClickedB(bool state);
    void on_camLed_clicked();
    void on_mot1Speed_clicked();
    void on_mot2Speed_clicked();
    void on_openButton_clicked();
    void on_regReadButton_clicked();
    void on_imgAction_clicked();

    void on_textClear_clicked();

    void on_writeRegButton_clicked();

private:
    Ui::MainWindow *ui;
};

void setParameterSend(uint16_t pindex, uint32_t val);
extern void buttonClickCallAport(uint16_t index);
extern void buttonClickCallBport(uint16_t index);

#endif // MAINWINDOW_H
