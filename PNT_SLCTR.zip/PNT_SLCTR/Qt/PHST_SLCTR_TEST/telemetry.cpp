#include "telemetry.h"
#include "mainwindow.h"
#include "ui_mainwindow.h"


void IOreadWriteControlTask()
{
    static uint8_t oldAport[23];
    static uint8_t oldBport[23];
    uint32_t i = 0;
    static uint8_t IOdrvieMode = IO_DRIVE_TOGGLE;
    static uint32_t AportPulseCntrs[23];
    static uint32_t BportPulseCntrs[23];

    switch(app.ioDriveMode)
    {
    case IO_DRIVE_TOGGLE:
        for(i = 0; i < 23; i++)
        {
            if(oldAport[i] != app.Aport[i])
            {
               setParameterSend(P_A1 + i, app.Aport[i]);
               oldAport[i] = app.Aport[i];
            }
        }
        for(i = 0; i < 23; i++)
        {
            if(oldBport[i] != app.Bport[i])
            {
               setParameterSend(P_B1 + i, app.Bport[i]);
               oldBport[i] = app.Bport[i];
            }
        }
        break;

    case IO_DRIVE_PULSE:
        for(i = 0; i < 23; i++)
        {
            if(oldAport[i] != app.Aport[i])
            {
               setParameterSend(P_A1 + i, app.Aport[i]);
               oldAport[i] = app.Aport[i];
            }
        }
        for(i = 0; i < 23; i++)
        {
            if(oldBport[i] != app.Bport[i])
            {
               setParameterSend(P_B1 + i, app.Bport[i]);
               oldBport[i] = app.Bport[i];
            }
        }

        for(i = 0; i < 23; i++)
        {
            if(app.Aport[i] == 1 && AportPulseCntrs[i] < IO_PULSE_PERIOD)
            {
               AportPulseCntrs[i] += TIMER_PERIOD;
            }
            else if(app.Aport[i] == 1 && AportPulseCntrs[i] >= IO_PULSE_PERIOD)
            {
                buttonClickCallAport(i);
            }
        }

        for(i = 0; i < 23; i++)
        {
            if(app.Bport[i] == 1 && BportPulseCntrs[i] < IO_PULSE_PERIOD)
            {
               BportPulseCntrs[i] += TIMER_PERIOD;
            }
            else if(app.Bport[i] == 1 && BportPulseCntrs[i] >= IO_PULSE_PERIOD)
            {
                buttonClickCallBport(i);
            }
        }
        break;

      case IO_DRIVE_BULK:
        break;

    }
}

