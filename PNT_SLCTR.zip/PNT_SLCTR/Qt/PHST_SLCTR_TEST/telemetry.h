#ifndef TELEMETRY_H
#define TELEMETRY_H

#include "qglobal.h"

void IOreadWriteControlTask();

#endif // TELEMETRY_H
