/*
 * usbdApp.c
 *
 *  Created on: 26 Nis 2020
 *      Author: yzcifci
 */

#include "usbdApp.h"
#include "bspErrorHandler.h"
#include "usbd_cdc_interface.h"

extern USBD_CDC_ItfTypeDef USBD_CDC_fops;
USBD_HandleTypeDef USBD_Device;


void initUSBD(uint32_t rxBuffAdd, uint32_t rxBuffHeadAdd, uint32_t rxBuffTailAdd, uint32_t rxBuffSized)
{
	rxBuff			= (uint8_t*)rxBuffAdd;
	rxBuffHead		= (uint32_t*)rxBuffHeadAdd;
	rxBuffTail		= (uint32_t*)rxBuffTailAdd;
	rxBuffSize		= rxBuffSized;

	USBD_Init(&USBD_Device, &VCP_Desc, 0);

	/* Add Supported Class */
	USBD_RegisterClass(&USBD_Device, USBD_CDC_CLASS);

	/* Add CDC Interface Class */
	USBD_CDC_RegisterInterface(&USBD_Device, &USBD_CDC_fops);

	/* Start Device Process */
	USBD_Start(&USBD_Device);

	HAL_PWREx_EnableUSBVoltageDetector();
}



