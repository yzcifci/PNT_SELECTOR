/*
 * usbdApp.h
 *
 *  Created on: 26 Nis 2020
 *      Author: yzcifci
 */

#ifndef USBD_USBDAPP_H_
#define USBD_USBDAPP_H_

#include "stm32h7xx_hal.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_cdc.h"
#include "usbd_cdc_interface.h"

extern void initUSBD(uint32_t rxBuffAdd, uint32_t rxBuffHeadAdd, uint32_t rxBuffTailAdd, uint32_t rxBuffSized);

#endif /* USBD_USBDAPP_H_ */
