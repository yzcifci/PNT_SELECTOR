/*
 * interface.h
 *
 *  Created on: 25 Nis 2020
 *      Author: yzcifci
 */

#ifndef APPLICATION_USER_INTERFACE_H_
#define APPLICATION_USER_INTERFACE_H_

#include "stm32h7xx_hal.h"
#include "bspErrorHandler.h"
#include "usbd_core.h"
#include "usbd_desc.h"
#include "usbd_cdc.h"

uint8_t *rxBuff;
uint32_t *rxBuffHead;
uint32_t *rxBuffTail;
uint32_t rxBuffSize;

void USBDsendData(uint8_t* add, uint32_t length);

#endif /* APPLICATION_USER_INTERFACE_H_ */
