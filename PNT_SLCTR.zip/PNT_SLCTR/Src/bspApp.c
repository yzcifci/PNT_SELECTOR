/*
 * bsp.c
 *
 *  Created on: 2 Nis 2020
 *      Author: yzcifci
 */

#include "bspApp.h"
#include "parameters.h"
#include "gpio.h"
#include "comController.h"
#include "camera.h"
#include "pulseOut.h"
#include "pwmOut.h"



void bsp10msCallTask()
{
	motorControlTask();
}

void bspTask()
{
	bspIOgetSet();
	cameraControlTask();
}

void cameraControlTask()
{
	switch(app.captureStatus)
	{
	case FRAME_CAPTURE_REQ:
		camera1SnapShotStart((uint8_t*)app.captureFrameAdd);
		app.captureStatus = FRAME_CAPTURING;
		break;

	case FRAME_CAPTURING:
		if(cam1CaptureStatus() == 1)
		{
			app.captureStatus = FRAME_CAPTURED;
		}
		break;
	}
}

void bspIOgetSet()
{
	HAL_GPIO_WritePin(SWITCH_A1_PORT ,SWITCH_A1_PIN, (uint8_t)PINT[P_A1].val);
	HAL_GPIO_WritePin(SWITCH_A2_PORT ,SWITCH_A2_PIN, (uint8_t)PINT[P_A2].val);
	HAL_GPIO_WritePin(SWITCH_A3_PORT ,SWITCH_A3_PIN, (uint8_t)PINT[P_A3].val);
	HAL_GPIO_WritePin(SWITCH_A4_PORT ,SWITCH_A4_PIN, (uint8_t)PINT[P_A4].val);
	HAL_GPIO_WritePin(SWITCH_A5_PORT ,SWITCH_A5_PIN, (uint8_t)PINT[P_A5].val);
	HAL_GPIO_WritePin(SWITCH_A6_PORT ,SWITCH_A6_PIN, (uint8_t)PINT[P_A6].val);
	HAL_GPIO_WritePin(SWITCH_A7_PORT ,SWITCH_A7_PIN, (uint8_t)PINT[P_A7].val);
	HAL_GPIO_WritePin(SWITCH_A8_PORT ,SWITCH_A8_PIN, (uint8_t)PINT[P_A8].val);
	HAL_GPIO_WritePin(SWITCH_A9_PORT ,SWITCH_A9_PIN, (uint8_t)PINT[P_A9].val);
	HAL_GPIO_WritePin(SWITCH_A10_PORT,SWITCH_A10_PIN, (uint8_t)PINT[P_A10].val);
	HAL_GPIO_WritePin(SWITCH_A11_PORT,SWITCH_A11_PIN, (uint8_t)PINT[P_A11].val);
	HAL_GPIO_WritePin(SWITCH_A12_PORT,SWITCH_A12_PIN, (uint8_t)PINT[P_A12].val);
	HAL_GPIO_WritePin(SWITCH_A13_PORT,SWITCH_A13_PIN, (uint8_t)PINT[P_A13].val);
	HAL_GPIO_WritePin(SWITCH_A14_PORT,SWITCH_A14_PIN, (uint8_t)PINT[P_A14].val);
	HAL_GPIO_WritePin(SWITCH_A15_PORT,SWITCH_A15_PIN, (uint8_t)PINT[P_A15].val);
	HAL_GPIO_WritePin(SWITCH_A16_PORT,SWITCH_A16_PIN, (uint8_t)PINT[P_A16].val);
	HAL_GPIO_WritePin(SWITCH_A17_PORT,SWITCH_A17_PIN, (uint8_t)PINT[P_A17].val);
	HAL_GPIO_WritePin(SWITCH_A18_PORT,SWITCH_A18_PIN, (uint8_t)PINT[P_A18].val);
	HAL_GPIO_WritePin(SWITCH_A19_PORT,SWITCH_A19_PIN, (uint8_t)PINT[P_A19].val);
	HAL_GPIO_WritePin(SWITCH_A20_PORT,SWITCH_A20_PIN, (uint8_t)PINT[P_A20].val);
	HAL_GPIO_WritePin(SWITCH_A21_PORT,SWITCH_A21_PIN, (uint8_t)PINT[P_A21].val);
	HAL_GPIO_WritePin(SWITCH_A22_PORT,SWITCH_A22_PIN, (uint8_t)PINT[P_A22].val);
	HAL_GPIO_WritePin(SWITCH_A23_PORT,SWITCH_A23_PIN, (uint8_t)PINT[P_A23].val);

	HAL_GPIO_WritePin(SWITCH_B1_PORT ,SWITCH_B1_PIN, (uint8_t)PINT[P_B1].val);
	HAL_GPIO_WritePin(SWITCH_B2_PORT ,SWITCH_B2_PIN, (uint8_t)PINT[P_B2].val);
	HAL_GPIO_WritePin(SWITCH_B3_PORT ,SWITCH_B3_PIN, (uint8_t)PINT[P_B3].val);
	HAL_GPIO_WritePin(SWITCH_B4_PORT ,SWITCH_B4_PIN, (uint8_t)PINT[P_B4].val);
	HAL_GPIO_WritePin(SWITCH_B5_PORT ,SWITCH_B5_PIN, (uint8_t)PINT[P_B5].val);
	HAL_GPIO_WritePin(SWITCH_B6_PORT ,SWITCH_B6_PIN, (uint8_t)PINT[P_B6].val);
	HAL_GPIO_WritePin(SWITCH_B7_PORT ,SWITCH_B7_PIN, (uint8_t)PINT[P_B7].val);
	HAL_GPIO_WritePin(SWITCH_B8_PORT ,SWITCH_B8_PIN, (uint8_t)PINT[P_B8].val);
	HAL_GPIO_WritePin(SWITCH_B9_PORT ,SWITCH_B9_PIN, (uint8_t)PINT[P_B9].val);
	HAL_GPIO_WritePin(SWITCH_B10_PORT,SWITCH_B10_PIN, (uint8_t)PINT[P_B10].val);
	HAL_GPIO_WritePin(SWITCH_B11_PORT,SWITCH_B11_PIN, (uint8_t)PINT[P_B11].val);
	HAL_GPIO_WritePin(SWITCH_B12_PORT,SWITCH_B12_PIN, (uint8_t)PINT[P_B12].val);
	HAL_GPIO_WritePin(SWITCH_B13_PORT,SWITCH_B13_PIN, (uint8_t)PINT[P_B13].val);
	HAL_GPIO_WritePin(SWITCH_B14_PORT,SWITCH_B14_PIN, (uint8_t)PINT[P_B14].val);
	HAL_GPIO_WritePin(SWITCH_B15_PORT,SWITCH_B15_PIN, (uint8_t)PINT[P_B15].val);
	HAL_GPIO_WritePin(SWITCH_B16_PORT,SWITCH_B16_PIN, (uint8_t)PINT[P_B16].val);
	HAL_GPIO_WritePin(SWITCH_B17_PORT,SWITCH_B17_PIN, (uint8_t)PINT[P_B17].val);
	HAL_GPIO_WritePin(SWITCH_B18_PORT,SWITCH_B18_PIN, (uint8_t)PINT[P_B18].val);
	HAL_GPIO_WritePin(SWITCH_B19_PORT,SWITCH_B19_PIN, (uint8_t)PINT[P_B19].val);
	HAL_GPIO_WritePin(SWITCH_B20_PORT,SWITCH_B20_PIN, (uint8_t)PINT[P_B20].val);
	HAL_GPIO_WritePin(SWITCH_B21_PORT,SWITCH_B21_PIN, (uint8_t)PINT[P_B21].val);
	HAL_GPIO_WritePin(SWITCH_B22_PORT,SWITCH_B22_PIN, (uint8_t)PINT[P_B22].val);
	HAL_GPIO_WritePin(SWITCH_B23_PORT,SWITCH_B23_PIN, (uint8_t)PINT[P_B23].val);

	setPWM(PINT[P_CAM_LED_PWM].val);
}

//this task must be called 10ms periodically
void motorControlTask()
{
	static float motor1CallPeriod=0.01;
	static float motor2CallPeriod=0.01;
	static float motor1Speed=0.0;
	static float motor2Speed=0.0;
	static uint32_t motor1Pulse=0;
	static uint32_t motor2Pulse=0;


	if(motor1Speed<(float)PINT[P_MOTOR1_SPEED_SET].val)
	{
		motor1Speed+=motor1CallPeriod*PINT[P_MOTOR1_ACC_SET].val;
		if(motor1Speed>(float)PINT[P_MOTOR1_SPEED_SET].val)motor1Speed=(float)PINT[P_MOTOR1_SPEED_SET].val;
		motor1Pulse=motor1Speed*MOTOR1_STEP_PER_MM;
		pulseOut1Set(motor1Pulse);
	}
	else if(motor1Speed>(float)PINT[P_MOTOR1_SPEED_SET].val)
	{
		motor1Speed-=motor1CallPeriod*PINT[P_MOTOR1_ACC_SET].val;
		if(motor1Speed<(float)PINT[P_MOTOR1_SPEED_SET].val)motor1Speed=(float)PINT[P_MOTOR1_SPEED_SET].val;
		motor1Pulse=motor1Speed*MOTOR1_STEP_PER_MM;
		pulseOut1Set(motor1Pulse);
	}


	if(motor2Speed<(float)PINT[P_MOTOR2_SPEED_SET].val)
	{
		motor2Speed+=motor2CallPeriod*PINT[P_MOTOR2_ACC_SET].val;
		if(motor2Speed>(float)PINT[P_MOTOR2_SPEED_SET].val)motor2Speed=(float)PINT[P_MOTOR2_SPEED_SET].val;
		motor2Pulse=motor2Speed*MOTOR2_STEP_PER_MM;
		pulseOut2Set(motor2Pulse);
	}
	else if(motor2Speed>(float)PINT[P_MOTOR2_SPEED_SET].val)
	{
		motor2Speed-=motor2CallPeriod*PINT[P_MOTOR2_ACC_SET].val;
		if(motor2Speed<(float)PINT[P_MOTOR2_SPEED_SET].val)motor2Speed=(float)PINT[P_MOTOR2_SPEED_SET].val;
		motor2Pulse=motor2Speed*MOTOR2_STEP_PER_MM;
		pulseOut2Set(motor2Pulse);
	}

}

void MPU_Config( void )
{
	MPU_Region_InitTypeDef MPU_InitStruct;

	HAL_MPU_Disable();

	//Configure the MPU attributes as WT for SRAM
	MPU_InitStruct.Enable           = MPU_REGION_ENABLE;
	MPU_InitStruct.BaseAddress      = 0x24000000;
	MPU_InitStruct.Size             = MPU_REGION_SIZE_512KB;
	MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
	MPU_InitStruct.IsBufferable     = MPU_ACCESS_NOT_BUFFERABLE;
	MPU_InitStruct.IsCacheable      = MPU_ACCESS_CACHEABLE;
	MPU_InitStruct.IsShareable      = MPU_ACCESS_SHAREABLE;
	MPU_InitStruct.Number           = MPU_REGION_NUMBER0;
	MPU_InitStruct.TypeExtField     = MPU_TEX_LEVEL0;
	MPU_InitStruct.SubRegionDisable = 0x00;
	MPU_InitStruct.DisableExec      = MPU_INSTRUCTION_ACCESS_ENABLE;
	HAL_MPU_ConfigRegion(&MPU_InitStruct);

	MPU_InitStruct.Enable           = MPU_REGION_ENABLE;
	MPU_InitStruct.BaseAddress      = 0x30000000;
	MPU_InitStruct.Size             = MPU_REGION_SIZE_256KB;
	MPU_InitStruct.AccessPermission = MPU_REGION_FULL_ACCESS;
	MPU_InitStruct.IsBufferable     = MPU_ACCESS_NOT_BUFFERABLE;
	MPU_InitStruct.IsCacheable      = MPU_ACCESS_CACHEABLE;
	MPU_InitStruct.IsShareable      = MPU_ACCESS_SHAREABLE;
	MPU_InitStruct.Number           = MPU_REGION_NUMBER1;
	MPU_InitStruct.TypeExtField     = MPU_TEX_LEVEL0;
	MPU_InitStruct.SubRegionDisable = 0x00;
	MPU_InitStruct.DisableExec      = MPU_INSTRUCTION_ACCESS_ENABLE;
	HAL_MPU_ConfigRegion(&MPU_InitStruct);

	HAL_MPU_Enable(MPU_PRIVILEGED_DEFAULT);
}
