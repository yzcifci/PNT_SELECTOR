/*
 * bsp.h
 *
 *  Created on: 2 Nis 2020
 *      Author: yzcifci
 */

#ifndef BSPAPP_H_
#define BSPAPP_H_

void bspTask();
void bspIOgetSet();
void cameraControlTask();
void motorControlTask();
void bsp10msCallTask();
void MPU_Config( void );
#endif /* BSPAPP_H_ */
