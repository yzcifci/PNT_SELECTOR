/*
 * comController.c
 *
 *  Created on: 3 Nis 2020
 *      Author: yzcifci
 *
 *COM_START(0x23469198)
 *COMMAND(0-255)
 *COM_DATA_LENGTH(0-65535)
 *COM_DATA:
 *
 *COMMAND_WRITE_REG
 *data 0:camera number
 *data 1:address
 *data 2:data
 *
 *COMMAND_READ_REG
 *data 0:camera number
 *data 1:address
 *
 *COMMAND_SET_PARAMETER
 *data 0:parameter index lower byte
 *data 1:parameter index higher byte
 *data 2:0 of uint32 data (lower byte)
 *data 3:1 of uint32 data
 *data 4:2 of uint32 data
 *data 5:3 of uint32 data (higher byte)
 *
 */

#include "comController.h"
#include "parameters.h"
#include "camera.h"
#include "i2c.h"
#include "uart.h"
#include "bspErrorHandler.h"
#include "usbdApp.h"

#define COMMAND_START		0x23469198

uint32_t totalLength 		= 0;
uint32_t totalLengthCntr	= 0;
uint16_t partialLength      = 0;
uint16_t partialLengthCntr  = 0;
uint8_t comState 			= 0;
uint8_t command		 		= 0;
uint8_t ackTrig				= 0;
uint8_t commandData[COMMAND_BUFFER_SIZE];



void comRecevieControlTask()
{
	static uint8_t array8[4];
	static uint16_t cnt32 = 0;
	static uint16_t cnt16 = 0;



	//RECEIVE CONTROL TASK
	while(app.rx.head != app.rx.tail)
	{
		if(comState == COM_HANDLE) return;
		switch(comState)
		{
		case COM_START:
			array8[0] = array8[1];
			array8[1] = array8[2];
			array8[2] = array8[3];
			array8[3] = app.rx.buff[app.rx.tail];

			if(array8[0] == (uint8_t)(COMMAND_START & 0x000000FF) &&
					array8[1] == (uint8_t)((COMMAND_START >> 8) & 0x000000FF) &&
					array8[2] == (uint8_t)((COMMAND_START >> 16) & 0x000000FF) &&
					array8[3] == (uint8_t)((COMMAND_START >> 24) & 0x000000FF))
			{
				comState = COM_COMMAND;
				partialLength = 0;
				partialLengthCntr = 0;
				totalLength = 0;
				cnt32 = 0;
			}
			else if((array8[0] == 'l') && (array8[1] == 'o') && (array8[2] == 'o') && (array8[3] == 'p'))
			{
				app.tx.buff[0] = 'l';
				app.tx.buff[1] = 'o';
				app.tx.buff[2] = 'o';
				app.tx.buff[3] = 'p';
				USBDsendData((uint8_t*)app.tx.buff, 4);
			}

			break;
		case COM_COMMAND:
			if(app.rx.buff[app.rx.tail] == COMMAND_ACK)
			{
				ackTrig = 1;
				comState = COM_START;
			}
			else
			{
				command = app.rx.buff[app.rx.tail];
				comState = COM_DATA_LENGTH;
			}

			break;
		case COM_DATA_LENGTH:
		{
			static union32 datalengthUni32;
			datalengthUni32.array[cnt32++] = app.rx.buff[app.rx.tail];
			if(cnt32 >= 4)
			{
				totalLength = datalengthUni32.data;
				cnt32 = 0;
				comState = COM_PARTIAL_DATA_LENGTH;
			}
			break;
		}

		case COM_PARTIAL_DATA_LENGTH:
		{
			static union16 datalengthUni16;
			datalengthUni16.array[cnt16++] = app.rx.buff[app.rx.tail];
			if(cnt16 >= 2)
			{
				comState = COM_DATA;
				partialLength = datalengthUni16.data;
				cnt16 = 0;

				if(partialLength == 0)
				{
					comState = COM_HANDLE;
				}
			}
		}

		break;
		case COM_DATA:
			if(partialLengthCntr < partialLength)
			{
				commandData[partialLengthCntr++] = app.rx.buff[app.rx.tail];
			}

			if(partialLengthCntr == partialLength)
			{
				comState = COM_HANDLE;
				totalLengthCntr += partialLength;
				if(totalLengthCntr == totalLength)
				{
					totalLengthCntr = 0;
				}
			}


			if((partialLengthCntr > partialLength) || (partialLength > totalLength) || (totalLengthCntr > totalLength))
			{
				bspError(COM_WRONG_LENGTH_ERROR);
			}

			break;
		default:
			bspError(COM_WRONG_COM_STATE_ERROR);
			break;
		}
		app.rx.tail++;
		if(app.rx.tail == RX_BUFFER_SIZE)
		{
			app.rx.tail = 0;
		}
	}
}


void comProcessorTask()
{
	static union32 comStart;
	static union32 uniData32;
	static union16 uniData16;
	static union32 totalDataLengthUni32;
	static union16 partialDataLengthUni16;
	static uint32_t sendBuffCntr = 0;

	uint32_t i = 0;
	comStart.data = COMMAND_START;

	switch(command)
	{
	case COMMAND_WRITE_REG:
		if(commandData[0] == CAMERA1)
		{
			cam1Write(commandData[1], commandData[2]);
		}
		else if(commandData[0] == CAMERA2)
		{
			cam2Write(commandData[1], commandData[2]);
		}
		command = COMMAND_NONE;
		comState = COM_START;
		break;

	case COMMAND_READ_REG:
		totalDataLengthUni32.data = 1;
		partialDataLengthUni16.data = 1;
		app.tx.buff[i++] = comStart.array[0];
		app.tx.buff[i++] = comStart.array[1];
		app.tx.buff[i++] = comStart.array[2];
		app.tx.buff[i++] = comStart.array[3];
		app.tx.buff[i++] = COMMAND_READ_REG;
		app.tx.buff[i++] = totalDataLengthUni32.array[0];
		app.tx.buff[i++] = totalDataLengthUni32.array[1];
		app.tx.buff[i++] = totalDataLengthUni32.array[2];
		app.tx.buff[i++] = totalDataLengthUni32.array[3];
		app.tx.buff[i++] = partialDataLengthUni16.array[0];
		app.tx.buff[i++] = partialDataLengthUni16.array[1];
		if(commandData[0] == CAMERA1)
		{
			//xxx test start cam reead commented for bsp error
			//			app.tx.buff[i++] = cam1Read(commandData[1]);
			app.tx.buff[i++] = 23;
			// test end
		}
		else if(commandData[0] == CAMERA2)
		{
			app.tx.buff[i++]  = cam2Read(commandData[1]);
		}
		USBDsendData((uint8_t*)app.tx.buff, i);
		command = COMMAND_NONE;
		comState = COM_START;
		break;

	case COMMAND_SET_PARAMETER:
		uniData16.array[0] = commandData[0];
		uniData16.array[1] = commandData[1];
		uniData32.array[0] = commandData[2];
		uniData32.array[1] = commandData[3];
		uniData32.array[2] = commandData[4];
		uniData32.array[3] = commandData[5];
		setParameter(uniData16.data, uniData32.data);
		command = COMMAND_NONE;
		comState = COM_START;
		break;

	case COMMAND_GET_IMAGE:
	{
#define PARTIAL_SEND_SIZE 512

		switch(app.captureStatus)
		{
		case FRAME_IDLE:



			//xxx test start captureStatus
			//			app.captureStatus = FRAME_CAPTURE_REQ;
		{
			app.captureStatus = FRAME_CAPTURED;
		}

		comState = COM_START;
		sendBuffCntr = 0;
		break;

		case FRAME_CAPTURED:
			if((ackTrig == 1) || (sendBuffCntr == 0))
			{
				totalDataLengthUni32.data = (app.frameSizeX *app.frameSizeY * 2);
				app.tx.buff[i++] = comStart.array[0];
				app.tx.buff[i++] = comStart.array[1];
				app.tx.buff[i++] = comStart.array[2];
				app.tx.buff[i++] = comStart.array[3];
				app.tx.buff[i++] = COMMAND_GET_IMAGE;
				app.tx.buff[i++] = totalDataLengthUni32.array[0];
				app.tx.buff[i++] = totalDataLengthUni32.array[1];
				app.tx.buff[i++] = totalDataLengthUni32.array[2];
				app.tx.buff[i++] = totalDataLengthUni32.array[3];


				if((sendBuffCntr + PARTIAL_SEND_SIZE) > (CAPTURE_SIZEX * CAPTURE_SIZEY * 2))
				{
					partialDataLengthUni16.data =((CAPTURE_SIZEX * CAPTURE_SIZEY * 2)-sendBuffCntr);
					app.tx.buff[i++] = partialDataLengthUni16.array[0];
					app.tx.buff[i++] = partialDataLengthUni16.array[1];
					for(uint32_t j = 0; j < partialDataLengthUni16.data; j++)
					{
						app.tx.buff[i++] = *(uint8_t*)(app.captureFrameAdd + sendBuffCntr);
						sendBuffCntr++;
						command = COMMAND_NONE;
						app.captureStatus = FRAME_IDLE;
					}

				}
				else
				{
					partialDataLengthUni16.data = PARTIAL_SEND_SIZE;
					app.tx.buff[i++] = partialDataLengthUni16.array[0];
					app.tx.buff[i++] = partialDataLengthUni16.array[1];
					for(uint32_t j = 0; j < PARTIAL_SEND_SIZE; j++)
					{
						app.tx.buff[i++] = *(uint8_t*)(app.captureFrameAdd + sendBuffCntr);
						sendBuffCntr++;
					}
				}
				USBDsendData((uint8_t*)app.tx.buff, i);
				ackTrig = 0;
				comState = COM_START;
			}
			break;

		}
		break;
	}
	case COMMAND_NONE:
		break;

	default:
		bspError(WRONG_COMMAND_EXECUTE_ERROR);
	}
}



