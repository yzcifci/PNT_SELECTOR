/*
 * comController.h
 *
 *  Created on: 3 Nis 2020
 *      Author: yzcifci
 */

#ifndef COMCONTROLLER_H_
#define COMCONTROLLER_H_

enum
{
    COM_START,
    COM_COMMAND,
    COM_DATA_LENGTH,
    COM_PARTIAL_DATA_LENGTH,
    COM_DATA,
    COM_HANDLE,


};

enum
{
	COMMAND_NONE,
	COMMAND_WRITE_REG,
	COMMAND_READ_REG,
	COMMAND_SET_PARAMETER,
	COMMAND_GET_IMAGE,
	COMMAND_ACK,


};

void comRecevieControlTask();
void comProcessorTask();

#endif /* COMCONTROLLER_H_ */
