/*
 * imgSource.h
 *
 *  Created on: 14 May 2020
 *      Author: yzcifci
 */

#ifndef IMGSOURCE_H_
#define IMGSOURCE_H_

const char sampleRGB565_800x100[800*100*2];

#endif /* IMGSOURCE_H_ */
