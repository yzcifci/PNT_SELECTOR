/*
 * parameters.c
 *
 *  Created on: 10 ?ub 2020
 *      Author: yzcifci
 */


#include "parameters.h"


app_ app;


uint8_t timeFlag10ms=FALSE;
uint8_t timeFlag50ms=FALSE;
uint8_t timeFlag100ms=FALSE;
uint8_t timeFlag1000ms=FALSE;
uint8_t timeFlag2000ms=FALSE;


PINT_ PINT[P_TOTAL]=
{
		//      oldVal,   defaultVal,   val ,   min ,max            ,   override
		{		0	  ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A1                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A2                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A3                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A4                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A5                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A6                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A7                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A8                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A9                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A10                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A11                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A12                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A13                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A14                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A15                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A16                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A17                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A18                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A19                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A20                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A21                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A22                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_A23                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B1                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B2                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B3                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B4                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B5                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B6                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B7                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B8                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B9                 ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B10                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B11                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B12                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B13                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B14                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B15                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B16                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B17                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B18                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B19                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B20                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B21                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B22                ,
		{       0     ,   0         ,     0 ,   0   ,1              ,    FALSE        },//P_B23                ,
		{       0     ,   0         ,     0 ,   0   ,1000           ,    FALSE        },//P_MOTOR1_SPEED_SET     ,
		{       0     ,   0         ,     0 ,   0   ,1000           ,    FALSE        },//P_MOTOR2_SPEED_SET     ,
		{       0     ,   50        ,     0 ,   0   ,1000           ,    FALSE        },//P_MOTOR1_ACC_SET       ,
		{       0     ,   50        ,     0 ,   0   ,1000           ,    FALSE        },//P_MOTOR2_ACC_SET       ,
		{       0     ,   0         ,     0 ,   0   ,100            ,    FALSE        },//P_CAM_LED_PWM          ,


};


void initParameters()
{
	for(uint32_t i = 0; i < P_TOTAL; i++)PINT[i].val = PINT[i].defaultVal;
}

void setParameter(uint32_t index, uint32_t val)
{
	if(val < PINT[index].min)val = PINT[index].min;
	else if(val < PINT[index].max)val = PINT[index].max;
	else
	{
		PINT[index].val = val;
	}
}



