/*
 * parameters.h
 *
 *  Created on: 10 ?ub 2020
 *      Author: yzcifci
 */

#ifndef PARAMETERS_H_
#define PARAMETERS_H_
#include "bspErrorHandler.h"

#define CAMERA_FB_ADD		0x30000000

#define CAPTURE_SIZEX		800
#define CAPTURE_SIZEY		100

#define MOTOR1_STEP_PER_MM	20
#define MOTOR2_STEP_PER_MM	20

#define RX_BUFFER_SIZE		256
#define TX_BUFFER_SIZE		1024
#define COMMAND_BUFFER_SIZE		256

#define FALSE 0
#define TRUE 1


typedef union
{
	uint32_t data;
	uint8_t array[4];
}union32;

typedef union
{
	uint16_t data;
	uint8_t array[2];
}union16;

typedef struct
{
	uint32_t captureFrameAdd;
	uint16_t frameSizeX;
	uint16_t frameSizeY;
	uint8_t captureStatus;
	uint8_t cameraSel;
	struct
	{
	  uint32_t tail;
	  uint32_t head;
	  uint8_t buff[TX_BUFFER_SIZE];
	}tx;
	struct
	{
	  uint32_t tail;
	  uint32_t head;
	  uint8_t buff[RX_BUFFER_SIZE];
	}rx;
}app_;

extern app_ app;


uint8_t timeFlag10ms;
uint8_t timeFlag50ms;
uint8_t timeFlag100ms;
uint8_t timeFlag1000ms;
uint8_t timeFlag2000ms;

enum
{
	CURRENT_CAM_CAM1,
	CURRENT_CAM_CAM2
};

enum
{
	FRAME_IDLE,
	FRAME_CAPTURE_REQ,
	FRAME_CAPTURING,
	FRAME_CAPTURED,
};

typedef struct
{
	float oldVal;
	float defaultVal;
	float val;
	float min;
	float max;
	uint8_t override;
}PFLT_;

typedef struct
{
	uint32_t oldVal;
	uint32_t defaultVal;
	uint32_t val;
	uint32_t min;
	uint32_t max;
	uint8_t override;
}PINT_;

enum
{
	P_A1                 ,
	P_A2                 ,
	P_A3                 ,
	P_A4                 ,
	P_A5                 ,
	P_A6                 ,
	P_A7                 ,
	P_A8                 ,
	P_A9                 ,
	P_A10                ,
	P_A11                ,
	P_A12                ,
	P_A13                ,
	P_A14                ,
	P_A15                ,
	P_A16                ,
	P_A17                ,
	P_A18                ,
	P_A19                ,
	P_A20                ,
	P_A21                ,
	P_A22                ,
	P_A23                ,
	P_B1                 ,
	P_B2                 ,
	P_B3                 ,
	P_B4                 ,
	P_B5                 ,
	P_B6                 ,
	P_B7                 ,
	P_B8                 ,
	P_B9                 ,
	P_B10                ,
	P_B11                ,
	P_B12                ,
	P_B13                ,
	P_B14                ,
	P_B15                ,
	P_B16                ,
	P_B17                ,
	P_B18                ,
	P_B19                ,
	P_B20                ,
	P_B21                ,
	P_B22                ,
	P_B23                ,
	P_MOTOR1_SPEED_SET     ,
	P_MOTOR2_SPEED_SET     ,
	P_MOTOR1_ACC_SET       ,
	P_MOTOR2_ACC_SET       ,
	P_CAM_LED_PWM          ,

	P_TOTAL
};

PINT_ PINT[P_TOTAL];


void setParameter(uint32_t index, uint32_t val);
#endif /* PARAMETERS_H_ */
