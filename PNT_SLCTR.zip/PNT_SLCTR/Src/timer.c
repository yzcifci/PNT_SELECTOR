/*
 * timer.c
 *
 *  Created on: 5 Nis 2020
 *      Author: yzcifci
 */


#include "timer.h"
#include "parameters.h"
#include "bspApp.h"



void timer1msCall()
{
	static uint32_t timer10msCntr=0;
	static uint32_t timer50msCntr=0;
	static uint32_t timer100msCntr=0;
	static uint32_t timer1000msCntr=0;
	static uint32_t timer2000msCntr=0;



	if(timer10msCntr<9)
	{
		timer10msCntr++;
	}
	else
	{
		timer10msCntr=0;
		timeFlag10ms=TRUE;
		bsp10msCallTask();

	}

	if(timer50msCntr<49)
	{
		timer50msCntr++;
	}
	else
	{
		timer50msCntr=0;
		timeFlag50ms=TRUE;
	}

	if(timer100msCntr<99)
	{
		timer100msCntr++;
	}
	else
	{
		timer100msCntr=0;
		timeFlag100ms=TRUE;
	}

	if(timer1000msCntr<999)
	{
		timer1000msCntr++;
	}
	else
	{
		timer1000msCntr=0;
		timeFlag1000ms=TRUE;
	}

	if(timer2000msCntr<1999)
	{
		timer2000msCntr++;
	}
	else
	{
		timer2000msCntr=0;
		timeFlag2000ms=TRUE;
	}

}
