/*
 * timer.h
 *
 *  Created on: 5 Nis 2020
 *      Author: yzcifci
 */

#ifndef TIMER_H_
#define TIMER_H_

void timer1msCall();

#endif /* TIMER_H_ */
