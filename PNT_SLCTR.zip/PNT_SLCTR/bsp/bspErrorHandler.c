/*
 * bspErrorHandler.c
 *
 *  Created on: 27 Kas 2019
 *      Author: yzcifci
 */

#include "bspErrorHandler.h"

void bspError(uint16_t errorIndex)
{
	while(1);
}
