/*
 * camera.c
 *
 *  Created on: 7 ?ub 2020
 *      Author: yzcifci
 */

#include "camera.h"

#include "i2c.h"
#define CAMERA_START_OFFX	0
#define CAMERA_START_OFFY	0

uint8_t cameraSelection=CAMERA1;
DMA_HandleTypeDef hdma_dcmi;
DCMI_HandleTypeDef hdcmi;
static uint32_t captureSizeX=1600;
static uint32_t captureSizeY=100;
static uint8_t cam1FrameCaptured=0;
static uint8_t cam2FrameCaptured=0;
static const uint8_t uxga_regs[][2];
static const uint8_t rgb565_regs[][2];
static const uint8_t svga_regs[][2] ;

static void setCameraFrameSize(uint16_t frameSizeX, uint16_t frameSizeY);
static void cameraRegSet(uint8_t cameraNumber, uint8_t *add, uint32_t size);


/*
 *
 *  #define UXGA_WIDTH      			(1600)
 *  #define UXGA_HEIGHT     			(1200)
 *  SIZEL_HSIZE8_11_SET(UXGA_WIDTH)	=0x00
 *  SIZEL_HSIZE8_SET(UXGA_WIDTH)		=0x00
 *  SIZEL_VSIZE8_SET(UXGA_HEIGHT)	=0x00
 *  HSIZE8_SET(UXGA_WIDTH)			=0XC8
 *  VSIZE8_SET(UXGA_HEIGHT)			=0x96
 */
static const uint8_t uxga_regs[][2] = {
		{OV2640_BANK_SEL	, 	OV2640_BANK_SEL_SENSOR}, 		//select register bank 0x01 (0x00:DSP, 0x01:Sensor)		def
		{OV2640_COM7		,  	OV2640_COM7_RES_UXGA},			//set resolution to UXGA write 0x00 def:0x00)	def
		{OV2640_COM1		,  	0x0F | 0x80},					//write VSTRT, VND for UXGA write 0x0F def(0x0f) |0x80:means allow 3 dummy frames no need for this	def
		{OV2640_HSTART		,  	0x11},							//Horizontal reference start: HSTART:7:0(0x11)+REG32:2:0(0b110) = 142 for UXGA  	def
		{OV2640_HSTOP     	,	0x75},							//Horizontal reference stop HREFEND8:0(0x75)+REG32 5:3(0b110)=942 each LSB 1 increment shifts 2 pixel UXGA=942	def
		{OV2640_VSTART    	,	0x01},							//Vertical start def UXGA:7		def
		{OV2640_VSTOP		,  	0x97},							//Vertical end UXGA 607	((607-7)*2)=1200	def
		{OV2640_REG32      	,	0x36},							//Additional bits of HREFST, HREFEND  UXGA def		def
		{OV2640_BANK_SEL	,  	OV2640_BANK_SEL_DSP	},			//select DSP bank
		{OV2640_RESET 		,  	OV2640_RESET_DVP},				//reset DVP module
		{OV2640_SIZEL		,  	OV2640_SIZEL_HSIZE8_11_SET(OV2640_UXGA_WIDTH) | OV2640_SIZEL_HSIZE8_SET(OV2640_UXGA_WIDTH) | OV2640_SIZEL_VSIZE8_SET(OV2640_UXGA_HEIGHT)}, //set HSIZE, VSIZE
		{OV2640_HSIZE8		,   OV2640_HSIZE8_SET(OV2640_UXGA_WIDTH)},		// set dsp HSIZE for UXGA
		{OV2640_VSIZE8		,   OV2640_VSIZE8_SET(OV2640_UXGA_HEIGHT)},		// set dsp VSIZE for UXGA
		{OV2640_CTRL2		, 	OV2640_CTRL2_DCW_EN | OV2640_CTRL2_SDE_EN | OV2640_CTRL2_UV_AVG_EN | OV2640_CTRL2_CMX_EN | OV2640_CTRL2_UV_ADJ_EN},// enable DCW, SDE, AVG, CMX, ADJ
		{0					,   0},								// end marker
};

static const uint8_t svga_regs[][2] = {
		{OV2640_BANK_SEL,  OV2640_BANK_SEL_SENSOR},
		{OV2640_COM7,      OV2640_COM7_RES_SVGA},
		{OV2640_COM1,      0x0A | 0x80},
		{OV2640_HSTART,    0x11},
		{OV2640_HSTOP,     0x43},
		{OV2640_VSTART,    0x01}, // 0x01 fixes issue with garbage pixels in the image...
		{OV2640_VSTOP,     0x97},
		{OV2640_REG32,     0x09},
		{OV2640_BANK_SEL,  OV2640_BANK_SEL_DSP},
		{OV2640_RESET,     OV2640_RESET_DVP},
		{OV2640_SIZEL,     OV2640_SIZEL_HSIZE8_11_SET(OV2640_SVGA_WIDTH) | OV2640_SIZEL_HSIZE8_SET(OV2640_SVGA_WIDTH) | OV2640_SIZEL_VSIZE8_SET(OV2640_SVGA_HEIGHT)},
		{OV2640_HSIZE8,    OV2640_HSIZE8_SET(OV2640_SVGA_WIDTH)},
		{OV2640_VSIZE8,    OV2640_VSIZE8_SET(OV2640_SVGA_HEIGHT)},
		{OV2640_CTRL2,     OV2640_CTRL2_DCW_EN | OV2640_CTRL2_SDE_EN | OV2640_CTRL2_UV_AVG_EN | OV2640_CTRL2_CMX_EN | OV2640_CTRL2_UV_ADJ_EN},
		{0,         0},

};

static const uint8_t rgb565_regs[][2] = {
		{OV2640_BANK_SEL	,    OV2640_BANK_SEL_DSP},
		{OV2640_R_BYPASS	,    OV2640_R_BYPASS_DSP_EN},
		{OV2640_IMAGE_MODE	,    OV2640_IMAGE_MODE_RGB565},
		{0xd7				,    0x03},
		{OV2640_RESET		,    0x00},
		{OV2640_R_BYPASS	,    OV2640_R_BYPASS_DSP_EN},
		{0					,    0},
};


static void setCameraFrameSize(uint16_t frameSizeX, uint16_t frameSizeY)
{
	const uint8_t (*regs)[2];
	uint16_t sensor_w = 0;
	uint16_t sensor_h = 0;
	uint16_t w = frameSizeX;
	uint16_t h = frameSizeY;
	uint32_t regSize;

	if ((w % 4) || (h % 4))
	{ // w/h must be divisble by 4
		bspError(CAMERA_RESOLUTION_ERROR);

	}


	if ((w <= OV2640_SVGA_WIDTH) && (h <= OV2640_SVGA_HEIGHT))
	{
		regs = svga_regs;
		regSize=sizeof(svga_regs);
		sensor_w = OV2640_SVGA_WIDTH;
		sensor_h = OV2640_SVGA_HEIGHT;

	} else
	{
		regs = uxga_regs;
		regSize=sizeof(uxga_regs);
		sensor_w = OV2640_UXGA_WIDTH;
		sensor_h = OV2640_UXGA_HEIGHT;
	}

	cameraRegSet(CAMERA1, (uint8_t*)regs, regSize);

	uint64_t tmp_div = IM_MIN(sensor_w / w, sensor_h / h);
	uint16_t log_div = IM_MIN(IM_LOG2(tmp_div) - 1, 3);
	uint16_t div = 1 << log_div;
	uint16_t w_mul = w * div;
	uint16_t h_mul = h * div;
	uint16_t x_off = (sensor_w - w_mul) / 2;
	uint16_t y_off = (sensor_h - h_mul) / 2;


	cam1Write(OV2640_CTRLI, OV2640_CTRLI_LP_DP | OV2640_CTRLI_V_DIV_SET(log_div) | OV2640_CTRLI_H_DIV_SET(log_div));
	cam1Write(OV2640_HSIZE, OV2640_HSIZE_SET(w_mul));
	cam1Write(OV2640_VSIZE, OV2640_VSIZE_SET(h_mul));
	cam1Write(OV2640_XOFFL, OV2640_XOFFL_SET(x_off));
	cam1Write(OV2640_YOFFL, OV2640_YOFFL_SET(y_off));
	cam1Write(OV2640_VHYX,  OV2640_VHYX_HSIZE_SET(w_mul) | OV2640_VHYX_VSIZE_SET(h_mul) | OV2640_VHYX_XOFF_SET(x_off) | OV2640_VHYX_YOFF_SET(y_off));
	cam1Write(OV2640_TEST,  OV2640_TEST_HSIZE_SET(w_mul));
	cam1Write(OV2640_ZMOW,  OV2640_ZMOW_OUTW_SET(w));
	cam1Write(OV2640_ZMOH,  OV2640_ZMOH_OUTH_SET(h));
	cam1Write(OV2640_ZMHH,  OV2640_ZMHH_OUTW_SET(w) | OV2640_ZMHH_OUTH_SET(h));
	cam1Write(OV2640_R_DVP_SP, div);
	cam1Write(OV2640_RESET, 0x00);

	HAL_Delay(100);
}





static void cameraRegSet(uint8_t cameraNumber, uint8_t *add, uint32_t size)
{
	uint32_t i;
	switch(cameraNumber)
	{
	case CAMERA1:
		for(i=0;i<size;i+=2)
		{
			cam1Write(add[i],add[i+1]);
		}
		break;
	case CAMERA2:
		for(i=0;i<size;i+=2)
		{
			cam2Write(add[i],add[i+1]);
		}
		break;
	default:
		bspError(WRONG_CAMERA_NUMBER_ERROR);
		break;

	}
}

void initCamera(uint16_t captureSizeXval, uint16_t captureSizeYval)
{

	captureSizeX = captureSizeXval;
	captureSizeY = captureSizeYval;
	hdcmi.Instance = DCMI;
	hdcmi.Init.SynchroMode = DCMI_SYNCHRO_HARDWARE;
	hdcmi.Init.PCKPolarity = DCMI_PCKPOLARITY_RISING;
	hdcmi.Init.VSPolarity = DCMI_VSPOLARITY_LOW;
	hdcmi.Init.HSPolarity = DCMI_HSPOLARITY_HIGH;
	hdcmi.Init.CaptureRate = DCMI_CR_ALL_FRAME;
	hdcmi.Init.ExtendedDataMode = DCMI_EXTEND_DATA_8B;
	hdcmi.Init.JPEGMode = DCMI_JPEG_DISABLE;
	hdcmi.Init.ByteSelectMode = DCMI_BSM_ALL;
	hdcmi.Init.ByteSelectStart = DCMI_OEBS_ODD;
	hdcmi.Init.LineSelectMode = DCMI_LSM_ALL;
	hdcmi.Init.LineSelectStart = DCMI_OELS_ODD;

	if (HAL_DCMI_Init(&hdcmi) != HAL_OK)
	{
		bspError(DCMI_INIT_ERROR);
	}


	setCameraFrameSize(1600,1200);
	cameraRegSet(CAMERA1, (uint8_t*)rgb565_regs,sizeof(rgb565_regs));


}

void camera1SnapShotStart(uint8_t *fb)
{
	if(cameraSelection!=CAMERA1)
	{
		cam1FrameCaptured=0;
		HAL_DCMI_MspDeInit(&hdcmi);
		cameraSelection=CAMERA1;
		HAL_DCMI_MspInit(&hdcmi);
	}
	if(HAL_DCMI_ConfigCrop(&hdcmi, CAMERA_START_OFFX, CAMERA_START_OFFY, captureSizeX, captureSizeY)!=HAL_OK)
	{
		bspError(DCMI_CONFIG_CROP_ERROR);
	}

	if(HAL_DCMI_EnableCrop(&hdcmi)!=HAL_OK)
	{
		bspError(DCMI_ENABLE_CROP_ERROR);
	}

	if(HAL_DCMI_Start_DMA(&hdcmi, DCMI_MODE_SNAPSHOT, (uint32_t)fb, captureSizeX*captureSizeY*2)!=HAL_OK)
	{
		bspError(CAMERA1_DCMI_DMA_SNAPSHOT_START_ERROR);
	}

}

void camera2SnapShotStart( uint8_t *fb)
{
	if(cameraSelection!=CAMERA2)
	{
		cam2FrameCaptured=0;
		HAL_DCMI_MspDeInit(&hdcmi);
		cameraSelection=CAMERA2;
		HAL_DCMI_MspInit(&hdcmi);
	}
	if(HAL_DCMI_ConfigCrop(&hdcmi, CAMERA_START_OFFX, CAMERA_START_OFFY, captureSizeX, captureSizeY)!=HAL_OK)
	{
		bspError(DCMI_CONFIG_CROP_ERROR);
	}

	if(HAL_DCMI_EnableCrop(&hdcmi)!=HAL_OK)
	{
		bspError(DCMI_ENABLE_CROP_ERROR);
	}

	if(HAL_DCMI_Start_DMA(&hdcmi, DCMI_MODE_SNAPSHOT, (uint32_t)fb, captureSizeX*captureSizeY*2)!=HAL_OK)
	{
		bspError(CAMERA2_DCMI_DMA_SNAPSHOT_START_ERROR);
	}

}

uint8_t cam1CaptureStatus()
{
	return cam1FrameCaptured;
}
uint8_t cam2CaptureStatus()
{
	return cam2FrameCaptured;
}


/*
 *  CAMERA1 PINS:
 *  PE4     ------> DCMI_D4
 *  PE5     ------> DCMI_D6
 *  PE6     ------> DCMI_D7
 *  PA4     ------> DCMI_HSYNC
 *  PA6     ------> DCMI_PIXCLK
 *  PH9     ------> DCMI_D0
 *  PH10     ------> DCMI_D1
 *  PH11     ------> DCMI_D2
 *  PH12     ------> DCMI_D3
 *  PD3     ------> DCMI_D5
 *  PG9     ------> DCMI_VSYNC
 *  CAMERA 2 PINS:
 *  PA6     ------> DCMI_PIXCLK
 *  PH8     ------> DCMI_HSYNC
 *  PC6     ------> DCMI_D0
 *  PA10     ------> DCMI_D1
 *  PC11     ------> DCMI_D4
 *  PB6     ------> DCMI_D5
 *  PB7     ------> DCMI_VSYNC
 *  PE0     ------> DCMI_D2
 *  PE1     ------> DCMI_D3
 *  PI6     ------> DCMI_D6
 *  PI7     ------> DCMI_D7
 *
 */
void HAL_DCMI_MspInit(DCMI_HandleTypeDef* hdcmi)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	if(hdcmi->Instance==DCMI)
	{
		__HAL_RCC_DMA1_CLK_ENABLE();
		if(cameraSelection==CAMERA1)
		{
			__HAL_RCC_DCMI_CLK_ENABLE();
			__HAL_RCC_GPIOE_CLK_ENABLE();
			__HAL_RCC_GPIOA_CLK_ENABLE();
			__HAL_RCC_GPIOH_CLK_ENABLE();
			__HAL_RCC_GPIOD_CLK_ENABLE();
			__HAL_RCC_GPIOG_CLK_ENABLE();

			GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

			GPIO_InitStruct.Pin = GPIO_PIN_4|GPIO_PIN_6;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

			GPIO_InitStruct.Pin = GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

			GPIO_InitStruct.Pin = GPIO_PIN_3;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

			GPIO_InitStruct.Pin = GPIO_PIN_9;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOG, &GPIO_InitStruct);
		}
		else
		{
			__HAL_RCC_DCMI_CLK_ENABLE();
			__HAL_RCC_GPIOA_CLK_ENABLE();
			__HAL_RCC_GPIOH_CLK_ENABLE();
			__HAL_RCC_GPIOC_CLK_ENABLE();
			__HAL_RCC_GPIOB_CLK_ENABLE();
			__HAL_RCC_GPIOE_CLK_ENABLE();
			__HAL_RCC_GPIOI_CLK_ENABLE();

			GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_10;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);

			GPIO_InitStruct.Pin = GPIO_PIN_8;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOH, &GPIO_InitStruct);

			GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_11;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOC, &GPIO_InitStruct);

			GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);

			GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);

			GPIO_InitStruct.Pin = GPIO_PIN_6|GPIO_PIN_7;
			GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
			GPIO_InitStruct.Pull = GPIO_NOPULL;
			GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
			GPIO_InitStruct.Alternate = GPIO_AF13_DCMI;
			HAL_GPIO_Init(GPIOI, &GPIO_InitStruct);

		}


		hdma_dcmi.Instance = DMA1_Stream0;
		hdma_dcmi.Init.Request = DMA_REQUEST_DCMI;
		hdma_dcmi.Init.Direction = DMA_PERIPH_TO_MEMORY;
		hdma_dcmi.Init.PeriphInc = DMA_PINC_DISABLE;
		hdma_dcmi.Init.MemInc = DMA_MINC_ENABLE;
		hdma_dcmi.Init.PeriphDataAlignment = DMA_PDATAALIGN_WORD;
		hdma_dcmi.Init.MemDataAlignment = DMA_MDATAALIGN_WORD;
		hdma_dcmi.Init.Mode = DMA_NORMAL;
		hdma_dcmi.Init.Priority = DMA_PRIORITY_LOW;
		hdma_dcmi.Init.FIFOMode = DMA_FIFOMODE_DISABLE;
		if (HAL_DMA_Init(&hdma_dcmi) != HAL_OK)
		{
			bspError(DCMI_DMA_INIT_ERROR);
		}

		__HAL_LINKDMA(hdcmi,DMA_Handle,hdma_dcmi);
		HAL_NVIC_SetPriority(DCMI_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(DCMI_IRQn);
		HAL_NVIC_SetPriority(DMA1_Stream0_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(DMA1_Stream0_IRQn);

	}

}




/**
 * @brief DCMI MSP De-Initialization
 * This function freeze the hardware resources used in this example
 * @param hdcmi: DCMI handle pointer
 * @retval None
 */
void HAL_DCMI_MspDeInit(DCMI_HandleTypeDef* hdcmi)
{
	if(hdcmi->Instance==DCMI)
	{
		if(cameraSelection==CAMERA1)
		{
			/* USER CODE BEGIN DCMI_MspDeInit 0 */

			/* USER CODE END DCMI_MspDeInit 0 */
			/* Peripheral clock disable */
			__HAL_RCC_DCMI_CLK_DISABLE();

			/**DCMI GPIO Configuration
		     PE4     ------> DCMI_D4
		     PE5     ------> DCMI_D6
		     PE6     ------> DCMI_D7
		     PA4     ------> DCMI_HSYNC
		     PA6     ------> DCMI_PIXCLK
		     PH9     ------> DCMI_D0
		     PH10     ------> DCMI_D1
		     PH11     ------> DCMI_D2
		     PH12     ------> DCMI_D3
		     PD3     ------> DCMI_D5
		     PG9     ------> DCMI_VSYNC
			 */
			HAL_GPIO_DeInit(GPIOE, GPIO_PIN_4|GPIO_PIN_5|GPIO_PIN_6);

			HAL_GPIO_DeInit(GPIOA, GPIO_PIN_4|GPIO_PIN_6);

			HAL_GPIO_DeInit(GPIOH, GPIO_PIN_9|GPIO_PIN_10|GPIO_PIN_11|GPIO_PIN_12);

			HAL_GPIO_DeInit(GPIOD, GPIO_PIN_3);

			HAL_GPIO_DeInit(GPIOG, GPIO_PIN_9);

			/* USER CODE BEGIN DCMI_MspDeInit 1 */

			/* USER CODE END DCMI_MspDeInit 1 */

		}
		else if(cameraSelection==CAMERA2)
		{
			/**DCMI GPIO Configuration
		    PA6     ------> DCMI_PIXCLK
		    PH8     ------> DCMI_HSYNC
		    PC6     ------> DCMI_D0
		    PA10     ------> DCMI_D1
		    PC11     ------> DCMI_D4
		    PB6     ------> DCMI_D5
		    PB7     ------> DCMI_VSYNC
		    PE0     ------> DCMI_D2
		    PE1     ------> DCMI_D3
		    PI6     ------> DCMI_D6
		    PI7     ------> DCMI_D7
			 */
			HAL_GPIO_DeInit(GPIOA, GPIO_PIN_6|GPIO_PIN_10);

			HAL_GPIO_DeInit(GPIOH, GPIO_PIN_8);

			HAL_GPIO_DeInit(GPIOC, GPIO_PIN_6|GPIO_PIN_11);

			HAL_GPIO_DeInit(GPIOB, GPIO_PIN_6|GPIO_PIN_7);

			HAL_GPIO_DeInit(GPIOE, GPIO_PIN_0|GPIO_PIN_1);

			HAL_GPIO_DeInit(GPIOI, GPIO_PIN_6|GPIO_PIN_7);


		}
	}
}

void DMA1_Stream0_IRQHandler(void)
{
	HAL_DMA_IRQHandler(&hdma_dcmi);
}

void DCMI_IRQHandler(void)
{
	HAL_DCMI_IRQHandler(&hdcmi);
}


void HAL_DCMI_FrameEventCallback(DCMI_HandleTypeDef *hdcmi)
{
	if(cameraSelection==CAMERA1)
	{
		cam1FrameCaptured=1;
	}
	else if(cameraSelection==CAMERA2)
	{
		cam2FrameCaptured=1;
	}
}







