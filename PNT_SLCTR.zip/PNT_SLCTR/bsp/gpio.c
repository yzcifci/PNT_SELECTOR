/*
 * gpio.c
 *
 *  Created on: 10 ?ub 2020
 *      Author: yzcifci
 */


#include "gpio.h"
#include "bspErrorHandler.h"

uint8_t pinAdefaultPinStateTable[32]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};
uint8_t pinBdefaultPinStateTable[32]={0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0,0};

void initGPIO(void)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	__HAL_RCC_GPIOF_CLK_ENABLE();

	GPIO_InitStruct.Pin = STEPPER1_STEP_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(STEPPER1_STEP_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = STEPPER1_DIR_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(STEPPER1_DIR_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = STEPPER2_STEP_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(STEPPER2_STEP_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = STEPPER2_DIR_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(STEPPER2_DIR_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = WORKING_LED_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(WORKING_LED_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = CAMERA_CLOCK_SELECT_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(CAMERA_CLOCK_SELECT_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = CAM1_PWDN_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(CAM1_PWDN_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = CAM1_RST_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(CAM1_RST_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = GPIO_PIN_10;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = CAM2_PWDN_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(CAM2_PWDN_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = CAM2_RST_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(CAM2_RST_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A1_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A1_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A2_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A2_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A3_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A3_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A4_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A4_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A5_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A5_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A6_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A6_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A7_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A7_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A8_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A8_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A9_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A9_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A10_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A10_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A11_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A11_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A12_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A12_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A13_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A13_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A14_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A14_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A15_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A15_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A16_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A16_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A17_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A17_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A18_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A18_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A19_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A19_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A20_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A20_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A21_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A21_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A22_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A22_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_A23_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_A23_PORT, &GPIO_InitStruct);

		GPIO_InitStruct.Pin = SWITCH_B1_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B1_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B2_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B2_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B3_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B3_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B4_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B4_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B5_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B5_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B6_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B6_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B7_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B7_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B8_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B8_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B9_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B9_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B10_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B10_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B11_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B11_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B12_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B12_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B13_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B13_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B14_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B14_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B15_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B15_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B16_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B16_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B17_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B17_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B18_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B18_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B19_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B19_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B20_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B20_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B21_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B21_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B22_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B22_PORT, &GPIO_InitStruct);

	GPIO_InitStruct.Pin = SWITCH_B23_PIN;
	GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
	GPIO_InitStruct.Pull = GPIO_NOPULL;
	GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	HAL_GPIO_Init(SWITCH_B23_PORT, &GPIO_InitStruct);

	groupAsetPin(pinAdefaultPinStateTable);
	groupBsetPin(pinBdefaultPinStateTable);

	cam1SetPwdn(0);
	cam2SetPwdn(1);

}


void toggleWorkingLed()
{
	HAL_GPIO_TogglePin(WORKING_LED_PORT,WORKING_LED_PIN);
}


void groupAsetPin(uint8_t * pinStateTable)
{
	HAL_GPIO_WritePin(SWITCH_A1_PORT,SWITCH_A1_PIN, pinStateTable[0]);
	HAL_GPIO_WritePin(SWITCH_A2_PORT,SWITCH_A2_PIN, pinStateTable[1]);
	HAL_GPIO_WritePin(SWITCH_A3_PORT,SWITCH_A3_PIN, pinStateTable[2]);
	HAL_GPIO_WritePin(SWITCH_A4_PORT,SWITCH_A4_PIN, pinStateTable[3]);
	HAL_GPIO_WritePin(SWITCH_A5_PORT,SWITCH_A5_PIN, pinStateTable[4]);
	HAL_GPIO_WritePin(SWITCH_A6_PORT,SWITCH_A6_PIN, pinStateTable[5]);
	HAL_GPIO_WritePin(SWITCH_A7_PORT,SWITCH_A7_PIN, pinStateTable[6]);
	HAL_GPIO_WritePin(SWITCH_A8_PORT,SWITCH_A8_PIN, pinStateTable[7]);
	HAL_GPIO_WritePin(SWITCH_A9_PORT,SWITCH_A9_PIN, pinStateTable[8]);
	HAL_GPIO_WritePin(SWITCH_A10_PORT,SWITCH_A10_PIN, pinStateTable[9]);
	HAL_GPIO_WritePin(SWITCH_A11_PORT,SWITCH_A11_PIN, pinStateTable[10]);
	HAL_GPIO_WritePin(SWITCH_A12_PORT,SWITCH_A12_PIN, pinStateTable[11]);
	HAL_GPIO_WritePin(SWITCH_A13_PORT,SWITCH_A13_PIN, pinStateTable[12]);
	HAL_GPIO_WritePin(SWITCH_A14_PORT,SWITCH_A14_PIN, pinStateTable[13]);
	HAL_GPIO_WritePin(SWITCH_A15_PORT,SWITCH_A15_PIN, pinStateTable[14]);
	HAL_GPIO_WritePin(SWITCH_A16_PORT,SWITCH_A16_PIN, pinStateTable[15]);
	HAL_GPIO_WritePin(SWITCH_A17_PORT,SWITCH_A17_PIN, pinStateTable[16]);
	HAL_GPIO_WritePin(SWITCH_A18_PORT,SWITCH_A18_PIN, pinStateTable[17]);
	HAL_GPIO_WritePin(SWITCH_A19_PORT,SWITCH_A19_PIN, pinStateTable[18]);
	HAL_GPIO_WritePin(SWITCH_A20_PORT,SWITCH_A20_PIN, pinStateTable[19]);
	HAL_GPIO_WritePin(SWITCH_A21_PORT,SWITCH_A21_PIN, pinStateTable[20]);
	HAL_GPIO_WritePin(SWITCH_A22_PORT,SWITCH_A22_PIN, pinStateTable[21]);
	HAL_GPIO_WritePin(SWITCH_A23_PORT,SWITCH_A23_PIN, pinStateTable[22]);
}

void groupBsetPin(uint8_t * pinStateTable)
{
	HAL_GPIO_WritePin(SWITCH_B1_PORT,SWITCH_B1_PIN, pinStateTable[0]);
	HAL_GPIO_WritePin(SWITCH_B2_PORT,SWITCH_B2_PIN, pinStateTable[1]);
	HAL_GPIO_WritePin(SWITCH_B3_PORT,SWITCH_B3_PIN, pinStateTable[2]);
	HAL_GPIO_WritePin(SWITCH_B4_PORT,SWITCH_B4_PIN, pinStateTable[3]);
	HAL_GPIO_WritePin(SWITCH_B5_PORT,SWITCH_B5_PIN, pinStateTable[4]);
	HAL_GPIO_WritePin(SWITCH_B6_PORT,SWITCH_B6_PIN, pinStateTable[5]);
	HAL_GPIO_WritePin(SWITCH_B7_PORT,SWITCH_B7_PIN, pinStateTable[6]);
	HAL_GPIO_WritePin(SWITCH_B8_PORT,SWITCH_B8_PIN, pinStateTable[7]);
	HAL_GPIO_WritePin(SWITCH_B9_PORT,SWITCH_B9_PIN, pinStateTable[8]);
	HAL_GPIO_WritePin(SWITCH_B10_PORT,SWITCH_B10_PIN, pinStateTable[9]);
	HAL_GPIO_WritePin(SWITCH_B11_PORT,SWITCH_B11_PIN, pinStateTable[10]);
	HAL_GPIO_WritePin(SWITCH_B12_PORT,SWITCH_B12_PIN, pinStateTable[11]);
	HAL_GPIO_WritePin(SWITCH_B13_PORT,SWITCH_B13_PIN, pinStateTable[12]);
	HAL_GPIO_WritePin(SWITCH_B14_PORT,SWITCH_B14_PIN, pinStateTable[13]);
	HAL_GPIO_WritePin(SWITCH_B15_PORT,SWITCH_B15_PIN, pinStateTable[14]);
	HAL_GPIO_WritePin(SWITCH_B16_PORT,SWITCH_B16_PIN, pinStateTable[15]);
	HAL_GPIO_WritePin(SWITCH_B17_PORT,SWITCH_B17_PIN, pinStateTable[16]);
	HAL_GPIO_WritePin(SWITCH_B18_PORT,SWITCH_B18_PIN, pinStateTable[17]);
	HAL_GPIO_WritePin(SWITCH_B19_PORT,SWITCH_B19_PIN, pinStateTable[18]);
	HAL_GPIO_WritePin(SWITCH_B20_PORT,SWITCH_B20_PIN, pinStateTable[19]);
	HAL_GPIO_WritePin(SWITCH_B21_PORT,SWITCH_B21_PIN, pinStateTable[20]);
	HAL_GPIO_WritePin(SWITCH_B22_PORT,SWITCH_B22_PIN, pinStateTable[21]);
	HAL_GPIO_WritePin(SWITCH_B23_PORT,SWITCH_B23_PIN, pinStateTable[22]);
}




void stp1SetDir(uint8_t dir )
{
	if(dir)
	{
		HAL_GPIO_WritePin(STEPPER1_DIR_PORT,STEPPER1_DIR_PIN,STEP1_DIR_FORWARD);
	}
	else
	{
		HAL_GPIO_WritePin(STEPPER1_DIR_PORT,STEPPER1_DIR_PIN,STEP1_DIR_BACKWARD);
	}
}

void stp2SetDir(uint8_t dir )
{
	if(dir)
	{
		HAL_GPIO_WritePin(STEPPER2_DIR_PORT,STEPPER2_DIR_PIN,STEP2_DIR_FORWARD);
	}
	else
	{
		HAL_GPIO_WritePin(STEPPER2_DIR_PORT,STEPPER2_DIR_PIN,STEP2_DIR_BACKWARD);
	}
}

void toggleStp1()
{
	HAL_GPIO_TogglePin(STEPPER1_STEP_PORT,STEPPER1_STEP_PIN);
}

void toggleStp2()
{
	HAL_GPIO_TogglePin(STEPPER2_STEP_PORT,STEPPER2_STEP_PIN);
}

void cam1Reset()
{
	HAL_GPIO_WritePin(CAM1_RST_PORT,CAM1_RST_PIN,1);
	HAL_Delay(10);
	HAL_GPIO_WritePin(CAM1_RST_PORT,CAM1_RST_PIN,0);
	HAL_Delay(30);
	HAL_GPIO_WritePin(CAM1_RST_PORT,CAM1_RST_PIN,1);
}

void cam2Reset()
{
	HAL_GPIO_WritePin(CAM2_RST_PORT,CAM2_RST_PIN,1);
	HAL_Delay(10);
	HAL_GPIO_WritePin(CAM2_RST_PORT,CAM2_RST_PIN,0);
	HAL_Delay(30);
	HAL_GPIO_WritePin(CAM2_RST_PORT,CAM2_RST_PIN,1);
}

void cam1SetPwdn(uint8_t state)
{
	HAL_GPIO_WritePin(CAM1_PWDN_PORT,CAM1_PWDN_PIN,state);
}

void cam2SetPwdn(uint8_t state)
{
	HAL_GPIO_WritePin(CAM2_PWDN_PORT,CAM2_PWDN_PIN,state);
}

void workingLedTest()
{
	initGPIO();
	while(1)
	{
		toggleWorkingLed();
		HAL_Delay(500);
	}
}




