/*
 * gpio.h
 *
 *  Created on: 10 ?ub 2020
 *      Author: yzcifci
 */
//#include "stdint.h"
#ifndef GPIO_H_
#define GPIO_H_

#define STEPPER1_STEP_PORT 			GPIOE
#define STEPPER1_STEP_PIN 			GPIO_PIN_0

#define STEPPER1_DIR_PORT 			GPIOE
#define STEPPER1_DIR_PIN 			GPIO_PIN_0

#define STEPPER2_STEP_PORT 			GPIOE
#define STEPPER2_STEP_PIN 			GPIO_PIN_0

#define STEPPER2_DIR_PORT 			GPIOE
#define STEPPER2_DIR_PIN 			GPIO_PIN_0

#define WORKING_LED_PORT 			GPIOE
#define WORKING_LED_PIN 			GPIO_PIN_0

#define CAMERA_CLOCK_SELECT_PORT	GPIOE
#define CAMERA_CLOCK_SELECT_PIN 	GPIO_PIN_0

#define CAM1_PWDN_PORT 				GPIOE			//PWDN active high
#define CAM1_PWDN_PIN 				GPIO_PIN_0

#define CAM1_RST_PORT 				GPIOE
#define CAM1_RST_PIN 				GPIO_PIN_0

#define CAM2_PWDN_PORT 				GPIOE
#define CAM2_PWDN_PIN 				GPIO_PIN_0

#define CAM2_RST_PORT 				GPIOE
#define CAM2_RST_PIN 				GPIO_PIN_0

#define SWITCH_A1_PORT 				GPIOE
#define SWITCH_A1_PIN 				GPIO_PIN_0

#define SWITCH_A2_PORT 				GPIOE
#define SWITCH_A2_PIN 				GPIO_PIN_0

#define SWITCH_A3_PORT 				GPIOE
#define SWITCH_A3_PIN 				GPIO_PIN_0

#define SWITCH_A3_PORT	 			GPIOE
#define SWITCH_A3_PIN 				GPIO_PIN_0

#define SWITCH_A4_PORT 				GPIOE
#define SWITCH_A4_PIN 				GPIO_PIN_0

#define SWITCH_A5_PORT 				GPIOE
#define SWITCH_A5_PIN 				GPIO_PIN_0

#define SWITCH_A6_PORT 				GPIOE
#define SWITCH_A6_PIN 				GPIO_PIN_0

#define SWITCH_A7_PORT 				GPIOE
#define SWITCH_A7_PIN 				GPIO_PIN_0

#define SWITCH_A8_PORT 				GPIOE
#define SWITCH_A8_PIN 				GPIO_PIN_0

#define SWITCH_A9_PORT 				GPIOE
#define SWITCH_A9_PIN 				GPIO_PIN_0

#define SWITCH_A10_PORT 			GPIOE
#define SWITCH_A10_PIN 				GPIO_PIN_0

#define SWITCH_A11_PORT 			GPIOE
#define SWITCH_A11_PIN 				GPIO_PIN_0

#define SWITCH_A12_PORT 			GPIOE
#define SWITCH_A12_PIN 				GPIO_PIN_0

#define SWITCH_A13_PORT 			GPIOE
#define SWITCH_A13_PIN 				GPIO_PIN_0

#define SWITCH_A14_PORT 			GPIOE
#define SWITCH_A14_PIN 				GPIO_PIN_0

#define SWITCH_A15_PORT 			GPIOE
#define SWITCH_A15_PIN 				GPIO_PIN_0

#define SWITCH_A16_PORT 			GPIOE
#define SWITCH_A16_PIN 				GPIO_PIN_0

#define SWITCH_A17_PORT 			GPIOE
#define SWITCH_A17_PIN 				GPIO_PIN_0

#define SWITCH_A18_PORT 			GPIOE
#define SWITCH_A18_PIN 				GPIO_PIN_0

#define SWITCH_A19_PORT	 			GPIOE
#define SWITCH_A19_PIN 				GPIO_PIN_0

#define SWITCH_A20_PORT 			GPIOE
#define SWITCH_A20_PIN 				GPIO_PIN_0

#define SWITCH_A21_PORT 			GPIOE
#define SWITCH_A21_PIN 				GPIO_PIN_0

#define SWITCH_A22_PORT 			GPIOE
#define SWITCH_A22_PIN 				GPIO_PIN_0

#define SWITCH_A23_PORT 			GPIOE
#define SWITCH_A23_PIN 				GPIO_PIN_0

#define SWITCH_B1_PORT 				GPIOE
#define SWITCH_B1_PIN 				GPIO_PIN_0

#define SWITCH_B2_PORT 				GPIOE
#define SWITCH_B2_PIN 				GPIO_PIN_0

#define SWITCH_B3_PORT 				GPIOE
#define SWITCH_B3_PIN 				GPIO_PIN_0

#define SWITCH_B3_PORT	 			GPIOE
#define SWITCH_B3_PIN 				GPIO_PIN_0

#define SWITCH_B4_PORT 				GPIOE
#define SWITCH_B4_PIN 				GPIO_PIN_0

#define SWITCH_B5_PORT 				GPIOE
#define SWITCH_B5_PIN 				GPIO_PIN_0

#define SWITCH_B6_PORT 				GPIOE
#define SWITCH_B6_PIN 				GPIO_PIN_0

#define SWITCH_B7_PORT 				GPIOE
#define SWITCH_B7_PIN 				GPIO_PIN_0

#define SWITCH_B8_PORT 				GPIOE
#define SWITCH_B8_PIN 				GPIO_PIN_0

#define SWITCH_B9_PORT 				GPIOE
#define SWITCH_B9_PIN 				GPIO_PIN_0

#define SWITCH_B10_PORT 			GPIOE
#define SWITCH_B10_PIN 				GPIO_PIN_0

#define SWITCH_B11_PORT 			GPIOE
#define SWITCH_B11_PIN 				GPIO_PIN_0

#define SWITCH_B12_PORT 			GPIOE
#define SWITCH_B12_PIN 				GPIO_PIN_0

#define SWITCH_B13_PORT 			GPIOE
#define SWITCH_B13_PIN 				GPIO_PIN_0

#define SWITCH_B14_PORT 			GPIOE
#define SWITCH_B14_PIN 				GPIO_PIN_0

#define SWITCH_B15_PORT 			GPIOE
#define SWITCH_B15_PIN 				GPIO_PIN_0

#define SWITCH_B16_PORT 			GPIOE
#define SWITCH_B16_PIN 				GPIO_PIN_0

#define SWITCH_B17_PORT 			GPIOE
#define SWITCH_B17_PIN 				GPIO_PIN_0

#define SWITCH_B18_PORT 			GPIOE
#define SWITCH_B18_PIN 				GPIO_PIN_0

#define SWITCH_B19_PORT	 			GPIOE
#define SWITCH_B19_PIN 				GPIO_PIN_0

#define SWITCH_B20_PORT 			GPIOE
#define SWITCH_B20_PIN 				GPIO_PIN_0

#define SWITCH_B21_PORT 			GPIOE
#define SWITCH_B21_PIN 				GPIO_PIN_0

#define SWITCH_B22_PORT 			GPIOE
#define SWITCH_B22_PIN 				GPIO_PIN_0

#define SWITCH_B23_PORT 			GPIOE
#define SWITCH_B23_PIN 				GPIO_PIN_0


enum
{
	STEP1_DIR_FORWARD,
	STEP1_DIR_BACKWARD
};

enum
{
	STEP2_DIR_FORWARD,
	STEP2_DIR_BACKWARD
};

void initGPIO(void);
void toggleWorkingLed();
void groupAsetPin(unsigned char * pinStateTable);
void groupBsetPin(unsigned char * pinStateTable);
void stp1SetDir(unsigned char dir );
void stp2SetDir(unsigned char dir );
void toggleStp1();
void toggleStp2();
void cam1Reset();
void cam2Reset();
void cam1SetPwdn(unsigned char state);
void cam2SetPwdn(unsigned char state);
void workingLedTest();


#endif /* GPIO_H_ */
