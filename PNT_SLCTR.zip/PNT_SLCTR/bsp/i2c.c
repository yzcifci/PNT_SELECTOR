/*
 * i2c.c
 *
 *  Created on: 11 ?ub 2020
 *      Author: yzcifci
 */

#include "i2c.h"
#include "bspErrorHandler.h"

I2C_HandleTypeDef hi2c1;
I2C_HandleTypeDef hi2c2;

uint8_t cam1I2cAdd=0x60;
uint8_t cam2I2cAdd=0x60;


void HAL_I2C_MspInit(I2C_HandleTypeDef* hi2c);
void HAL_I2C_MspDeInit(I2C_HandleTypeDef* hi2c);

void i2c1Init()
{
	hi2c1.Instance = I2C1;
	hi2c1.Init.Timing = 0x10707DBC;
	hi2c1.Init.OwnAddress1 = 0;
	hi2c1.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	hi2c1.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	hi2c1.Init.OwnAddress2 = 0;
	hi2c1.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
	hi2c1.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	hi2c1.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	if (HAL_I2C_Init(&hi2c1) != HAL_OK)
	{
		bspError(I2C1_INIT_ERROR);
	}
	/** Configure Analogue filter
	 */
	if (HAL_I2CEx_ConfigAnalogFilter(&hi2c1, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
	{
		bspError(I2C1_ANALOG_FILTER_CONFIG_ERROR);
	}
	/** Configure Digital filter
	 */
	if (HAL_I2CEx_ConfigDigitalFilter(&hi2c1, 0) != HAL_OK)
	{
		bspError(I2C1_DIGITAL_FILTER_CONFIG_ERROR);
	}
}


void i2c2Init()
{
	hi2c2.Instance = I2C2;
	hi2c2.Init.Timing = 0x10707DBC;
	hi2c2.Init.OwnAddress1 = 0;
	hi2c2.Init.AddressingMode = I2C_ADDRESSINGMODE_7BIT;
	hi2c2.Init.DualAddressMode = I2C_DUALADDRESS_DISABLE;
	hi2c2.Init.OwnAddress2 = 0;
	hi2c2.Init.OwnAddress2Masks = I2C_OA2_NOMASK;
	hi2c2.Init.GeneralCallMode = I2C_GENERALCALL_DISABLE;
	hi2c2.Init.NoStretchMode = I2C_NOSTRETCH_DISABLE;
	if (HAL_I2C_Init(&hi2c2) != HAL_OK)
	{
		bspError(I2C2_INIT_ERROR);
	}
	/** Configure Analogue filter
	 */
	if (HAL_I2CEx_ConfigAnalogFilter(&hi2c2, I2C_ANALOGFILTER_ENABLE) != HAL_OK)
	{
		bspError(I2C2_ANALOG_FILTER_CONFIG_ERROR);
	}
	/** Configure Digital filter
	 */
	if (HAL_I2CEx_ConfigDigitalFilter(&hi2c2, 0) != HAL_OK)
	{
		bspError(I2C2_DIGITAL_FILTER_CONFIG_ERROR);
	}

}


void cam1Write(uint8_t add, uint8_t data)
{
	if(HAL_I2C_Mem_Write(&hi2c1, (uint16_t)cam1I2cAdd ,(uint16_t)add, 1, (uint8_t *)&data, 1, 10)!=HAL_OK)
	{
		bspError(I2C1_WRITE_DATA_ERROR);
	}
}

void cam2Write(uint8_t add, uint8_t data)
{
	if(HAL_I2C_Mem_Write(&hi2c2, (uint16_t)cam2I2cAdd ,(uint16_t)add, 1, (uint8_t *)&data, 1, 10)!=HAL_OK)
	{
		bspError(I2C2_WRITE_DATA_ERROR);
	}
}

uint8_t cam1Read(uint8_t add)
{
	uint8_t data=0x00;
	if(HAL_I2C_Mem_Read(&hi2c1,cam1I2cAdd, (uint16_t) add , 1, (uint8_t*)&data, 1 , 10)!=HAL_OK)
	{
		bspError(I2C1_READ_DATA_ERROR);
	}
	return data;
}

uint8_t cam2Read(uint8_t add)
{
	uint8_t data=0x00;
	if(HAL_I2C_Mem_Read(&hi2c2,cam2I2cAdd, (uint16_t) add , 1, (uint8_t*)&data, 1 , 10)!=HAL_OK)
	{
		bspError(I2C2_READ_DATA_ERROR);
	}
	return data;
}









/**I2C1 GPIO Configuration
PB8     ------> I2C1_SCL
PB9     ------> I2C1_SDA
*/
/**I2C2 GPIO Configuration
PF0     ------> I2C2_SDA
PF1     ------> I2C2_SCL
*/
void HAL_I2C_MspInit(I2C_HandleTypeDef* hi2c)
{
  GPIO_InitTypeDef GPIO_InitStruct = {0};
  if(hi2c->Instance==I2C1)
  {
    __HAL_RCC_GPIOB_CLK_ENABLE();
    GPIO_InitStruct.Pin = GPIO_PIN_8|GPIO_PIN_9;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF4_I2C1;
    HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
    __HAL_RCC_I2C1_CLK_ENABLE();
  }
  else if(hi2c->Instance==I2C2)
  {
    __HAL_RCC_GPIOF_CLK_ENABLE();
    GPIO_InitStruct.Pin = GPIO_PIN_0|GPIO_PIN_1;
    GPIO_InitStruct.Mode = GPIO_MODE_AF_OD;
    GPIO_InitStruct.Pull = GPIO_NOPULL;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
    GPIO_InitStruct.Alternate = GPIO_AF4_I2C2;
    HAL_GPIO_Init(GPIOF, &GPIO_InitStruct);
    __HAL_RCC_I2C2_CLK_ENABLE();
  }

}



void HAL_I2C_MspDeInit(I2C_HandleTypeDef* hi2c)
{
  if(hi2c->Instance==I2C1)
  {
    __HAL_RCC_I2C1_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOB, GPIO_PIN_8|GPIO_PIN_9);
  }
  else if(hi2c->Instance==I2C2)
  {
    __HAL_RCC_I2C2_CLK_DISABLE();
    HAL_GPIO_DeInit(GPIOF, GPIO_PIN_0|GPIO_PIN_1);
  }
}
