/*
 * i2c.h
 *
 *  Created on: 11 ?ub 2020
 *      Author: yzcifci
 */

#ifndef I2C_H_
#define I2C_H_





/*
 * i2c.c
 *
 *  Created on: 11 ?ub 2020
 *      Author: yzcifci
 */

#include "i2c.h"
#include "bspErrorHandler.h"


void i2c1Init();
void i2c2Init();
void cam1Write(uint8_t add, uint8_t data);
void cam2Write(uint8_t add, uint8_t data);
uint8_t cam1Read(uint8_t add);
uint8_t cam2Read(uint8_t add);






#endif /* I2C_H_ */
