/*
 * pulseOut.c
 *
 *  Created on: 4 Nis 2020
 *      Author: yzcifci
 *
 *
 *
 */


#include "bspErrorHandler.h"

#define TIM1_FREQ		1000000
#define TIM2_FREQ		1000000

TIM_HandleTypeDef    Tim1Handle;
TIM_HandleTypeDef    Tim2Handle;
TIM_OC_InitTypeDef 	 Tim1sConfig;
TIM_OC_InitTypeDef 	 Tim2sConfig;

uint32_t tim1PrescVal = 0;
uint32_t tim2PrescVal = 0;


void initPulseOutput()
{
	tim1PrescVal 			      = (uint32_t)((SystemCoreClock / (TIM1_FREQ*2)) - 1);
	Tim1Handle.Instance 		  = TIM1;
	Tim1Handle.Init.Period        = 65535;
	Tim1Handle.Init.Prescaler     = tim1PrescVal;
	Tim1Handle.Init.ClockDivision = 0;
	Tim1Handle.Init.CounterMode   = TIM_COUNTERMODE_UP;
	if(HAL_TIM_OC_Init(&Tim1Handle) != HAL_OK)
	{
		bspError(TIM_OC_INIT_ERROR);
	}
	Tim1sConfig.OCMode     = TIM_OCMODE_TOGGLE;
	Tim1sConfig.OCPolarity = TIM_OCPOLARITY_LOW;


	tim2PrescVal 			      = (uint32_t)((SystemCoreClock / (TIM2_FREQ*2)) - 1);
	Tim2Handle.Instance 		  = TIM2;
	Tim2Handle.Init.Period        = 65535;
	Tim2Handle.Init.Prescaler     = tim2PrescVal;
	Tim2Handle.Init.ClockDivision = 0;
	Tim2Handle.Init.CounterMode   = TIM_COUNTERMODE_UP;
	if(HAL_TIM_OC_Init(&Tim2Handle) != HAL_OK)
	{
		bspError(TIM_OC_INIT_ERROR);
	}
	Tim2sConfig.OCMode     = TIM_OCMODE_TOGGLE;
	Tim2sConfig.OCPolarity = TIM_OCPOLARITY_LOW;





}



void pulseOut1Set(uint32_t freq)
{
	static uint32_t oldFreq=0;
	if(oldFreq!=freq)
	{
		if(freq==0)
		{
			if(HAL_TIM_OC_Stop(&Tim1Handle, TIM_CHANNEL_1) != HAL_OK)
			{
				bspError(TIM_OC_STOP_ERROR);
			}
		}
		else
		{
			Tim1sConfig.Pulse = (TIM1_FREQ/freq)/2;
			if(HAL_TIM_OC_ConfigChannel(&Tim1Handle, &Tim1sConfig, TIM_CHANNEL_1) != HAL_OK)
			{
				bspError(TIM_OC_CONFIG_CHANNEL_ERROR);
			}

			if(HAL_TIM_OC_Start(&Tim1Handle, TIM_CHANNEL_1) != HAL_OK)
			{
				bspError(TIM_OC_START_ERROR);
			}
			Tim1Handle.Instance->ARR=Tim1sConfig.Pulse;
		}
	}
	oldFreq=freq;
}

void pulseOut2Set(uint32_t freq)
{
	static uint32_t oldFreq=0;
	if(oldFreq!=freq)
	{
		if(freq==0)
		{
			if(HAL_TIM_OC_Stop(&Tim2Handle, TIM_CHANNEL_1) != HAL_OK)
			{
				bspError(TIM_OC_STOP_ERROR);
			}
		}
		else
		{
			Tim2sConfig.Pulse = (TIM2_FREQ/freq)/2;
			if(HAL_TIM_OC_ConfigChannel(&Tim2Handle, &Tim2sConfig, TIM_CHANNEL_1) != HAL_OK)
			{
				bspError(TIM_OC_CONFIG_CHANNEL_ERROR);
			}

			if(HAL_TIM_OC_Start(&Tim2Handle, TIM_CHANNEL_1) != HAL_OK)
			{
				bspError(TIM_OC_START_ERROR);
			}
			Tim2Handle.Instance->ARR=Tim2sConfig.Pulse;
		}
	}
	oldFreq=freq;
}

//MOTOR1 :TIM1_CHANNEL1 :PE9
//MOTOR2 :TIM2_CHANNEL1 :PA0
void HAL_TIM_OC_MspInit(TIM_HandleTypeDef *htim)
{
	 GPIO_InitTypeDef GPIO_InitStruct = {0};
	  if(htim->Instance==TIM1)
	  {
		__HAL_RCC_TIM1_CLK_ENABLE();
	    __HAL_RCC_GPIOE_CLK_ENABLE();
	    GPIO_InitStruct.Pin = GPIO_PIN_9;
	    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	    GPIO_InitStruct.Pull = GPIO_NOPULL;
	    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	    GPIO_InitStruct.Alternate = GPIO_AF1_TIM1;
	    HAL_GPIO_Init(GPIOE, &GPIO_InitStruct);
	  }
	  else if(htim->Instance==TIM2)
	  {
		__HAL_RCC_TIM2_CLK_ENABLE();
	    __HAL_RCC_GPIOA_CLK_ENABLE();
	    GPIO_InitStruct.Pin = GPIO_PIN_0;
	    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	    GPIO_InitStruct.Pull = GPIO_NOPULL;
	    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	    GPIO_InitStruct.Alternate = GPIO_AF1_TIM2;
	    HAL_GPIO_Init(GPIOA, &GPIO_InitStruct);
	  }

}




void pulseOutTest()
{
	initPulseOutput();

	while(1)
	{
		pulseOut1Set(100);
		pulseOut2Set(200);
		HAL_Delay(5000);
		pulseOut1Set(1000);
		pulseOut2Set(2000);
		HAL_Delay(5000);
		pulseOut1Set(10000);
		pulseOut2Set(20000);
		HAL_Delay(5000);
		pulseOut1Set(0);
		pulseOut2Set(0);
		HAL_Delay(5000);
	}



}
