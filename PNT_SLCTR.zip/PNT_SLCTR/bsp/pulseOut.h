/*
 * pulseOut.h
 *
 *  Created on: 4 Nis 2020
 *      Author: yzcifci
 */

#ifndef PULSEOUT_H_
#define PULSEOUT_H_

/*
 * pulseOut.c
 *
 *  Created on: 4 Nis 2020
 *      Author: yzcifci
 */


#include "bspErrorHandler.h"


void initPulseOutput();
void pulseOut1Set(uint32_t freq);
void pulseOut2Set(uint32_t freq);
void HAL_TIM_OC_MspInit(TIM_HandleTypeDef *htim);
void pulseOutTest();

#endif /* PULSEOUT_H_ */
