/*
 * pwmOut.c
 *
 *  Created on: 4 Nis 2020
 *      Author: yzcifci
 *
 *period =TIM4_PERIOD/TIM4_FREQ  =(20000/1000000)=20ms
 *duty will be percentage of this
 */


#include "pwmOut.h"


#define TIM4_FREQ   1000000
#define TIM4_PERIOD	20000

TIM_HandleTypeDef   tim4handle;
TIM_OC_InitTypeDef  tim4channel1;
uint32_t 			uhPrescalerValue;

void initPWM()
{
	uhPrescalerValue = (uint32_t)(SystemCoreClock / (2*TIM4_FREQ)) - 1;
	tim4handle.Instance = TIM4;
	tim4handle.Init.Prescaler         = uhPrescalerValue;
	tim4handle.Init.Period            = TIM4_PERIOD;
	tim4handle.Init.ClockDivision     = 0;
	tim4handle.Init.CounterMode       = TIM_COUNTERMODE_UP;
	tim4handle.Init.RepetitionCounter = 0;
	if (HAL_TIM_PWM_Init(&tim4handle) != HAL_OK)
	{
		bspError(PWM_INIT_ERROR);
	}

	tim4channel1.OCMode       = TIM_OCMODE_PWM1;
	tim4channel1.OCPolarity   = TIM_OCPOLARITY_HIGH;
	tim4channel1.OCFastMode   = TIM_OCFAST_DISABLE;
	tim4channel1.OCNPolarity  = TIM_OCNPOLARITY_HIGH;
	tim4channel1.OCNIdleState = TIM_OCNIDLESTATE_RESET;
	tim4channel1.OCIdleState  = TIM_OCIDLESTATE_RESET;
	tim4channel1.Pulse = 0;


}

void setPWM (uint32_t percentage)
{
	static uint32_t oldPercentage=0;
	if(percentage==oldPercentage)return;
	tim4channel1.Pulse = (percentage*TIM4_PERIOD)/100;
	if (HAL_TIM_PWM_ConfigChannel(&tim4handle, &tim4channel1, TIM_CHANNEL_1) != HAL_OK)
	{
		bspError(PWM_CONFIG_CHANNEL_ERROR);
	}
	if (HAL_TIM_PWM_Start(&tim4handle, TIM_CHANNEL_1) != HAL_OK)
	{
		bspError(PWM_START_ERROR);
	}
	oldPercentage=percentage;
}

//CAMERA_LED_PWM_OUT :TIM4_CHANNEL1 :PD12
void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim)
{
	GPIO_InitTypeDef   GPIO_InitStruct;
	if(htim->Instance==TIM4)
	{
		__HAL_RCC_TIM4_CLK_ENABLE();
	    __HAL_RCC_GPIOD_CLK_ENABLE();
	    GPIO_InitStruct.Pin = GPIO_PIN_12;
	    GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
	    GPIO_InitStruct.Pull = GPIO_NOPULL;
	    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
	    GPIO_InitStruct.Alternate = GPIO_AF2_TIM4;
	    HAL_GPIO_Init(GPIOD, &GPIO_InitStruct);

	}
}


void testPWM()
{
	initPWM();
	setPWM(70);
	while(1);
}


