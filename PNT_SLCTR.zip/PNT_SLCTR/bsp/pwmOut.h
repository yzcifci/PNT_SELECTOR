/*
 * pwmOut.h
 *
 *  Created on: 4 Nis 2020
 *      Author: yzcifci
 */

#ifndef PWMOUT_H_
#define PWMOUT_H_

#include "bspErrorHandler.h"

void initPWM();
void setPWM (uint32_t percentage);
void HAL_TIM_PWM_MspInit(TIM_HandleTypeDef *htim);
void testPWM();

#endif /* PWMOUT_H_ */
