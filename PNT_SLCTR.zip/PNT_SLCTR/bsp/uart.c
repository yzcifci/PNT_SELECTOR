/*
 * uart.c
 *
 *  Created on: 10 ?ub 2020
 *      Author: yzcifci
 *
 */


#include "uart.h"
#include "bspErrorHandler.h"
#include "i2c.h"
#include "camera.h"


UART_HandleTypeDef huart5;




void uartInit()
{
	huart5.Instance = UART5;
	huart5.Init.BaudRate = 960000;
	huart5.Init.WordLength = UART_WORDLENGTH_8B;
	huart5.Init.StopBits = UART_STOPBITS_1;
	huart5.Init.Parity = UART_PARITY_NONE;
	huart5.Init.Mode = UART_MODE_TX_RX;
	huart5.Init.HwFlowCtl = UART_HWCONTROL_NONE;
	huart5.Init.OverSampling = UART_OVERSAMPLING_16;
	huart5.Init.OneBitSampling = UART_ONE_BIT_SAMPLE_DISABLE;
	huart5.Init.ClockPrescaler = UART_PRESCALER_DIV1;
	huart5.AdvancedInit.AdvFeatureInit = UART_ADVFEATURE_NO_INIT;
	if (HAL_UART_Init(&huart5) != HAL_OK)
	{
		bspError(UART_INIT_ERROR);
	}
	if (HAL_UARTEx_SetTxFifoThreshold(&huart5, UART_TXFIFO_THRESHOLD_1_8) != HAL_OK)
	{

	}
	if (HAL_UARTEx_SetRxFifoThreshold(&huart5, UART_RXFIFO_THRESHOLD_1_8) != HAL_OK)
	{

	}
	if (HAL_UARTEx_DisableFifoMode(&huart5) != HAL_OK)
	{
		bspError(UART_DISABLE_FIFO_MODE_ERROR);

	}

	huart5.RxISR=uartReceiveCallBack;

	CLEAR_BIT(huart5.Instance->CR3, USART_CR3_EIE);
	SET_BIT(huart5.Instance->CR1, USART_CR1_RXNEIE_RXFNEIE);
}




void uartHeadPlusPlus()
{

}



void uartReceiveCallBack(struct __UART_HandleTypeDef *huart)
{
//	static uint8_t lock=0;
//	if(lock!=0)bspError(UART_DATA_RCV_OVERLFLOW_ERROR);
//	lock=1;
//
//	if(getUartEmptyBufferSize()>1)
//	{
//		*(uint8_t*)(PINT[P_COMRX_BUFF_ADD].val+PINT[P_COMRX_HEAD].val)=huart5.Instance->RDR;
//		uartHeadPlusPlus();
//	}
//	else
//	{
//		bspError(UART_DATA_BUFFER_OVERLFLOW_ERROR);
//	}
//	lock=0;
}


uint16_t getUartEmptyBufferSize()
{
//	if(PINT[P_COMRX_HEAD].val>PINT[P_COMRX_TAIL].val)
//	{
//		return PINT[P_COM_RX_BUFF_SIZE].val-(PINT[P_COMRX_HEAD].val-PINT[P_COMRX_TAIL].val);
//	}
//	else if(PINT[P_COMRX_HEAD].val<PINT[P_COMRX_TAIL].val)
//	{
//		return PINT[P_COMRX_TAIL].val-PINT[P_COMRX_HEAD].val;
//	}
//	else
//	{
//		return PINT[P_COM_RX_BUFF_SIZE].val;
//	}
	return 0;
}



void uartTransmitData(uint8_t* data, uint32_t length)
{
	if(length==0)bspError(UART_DATA_LENGTH_ZERO_ERROR);
	HAL_UART_Transmit(&huart5, (uint8_t *)data, length, 0xFFFF);
}

void testUart()
{
	char uartSampleData[32]={"Uart sample data sent\n"};
	uartInit();
	while(1)
	{
		HAL_Delay(500);
		uartTransmitData((uint8_t*)&uartSampleData[0],sizeof(uartSampleData));
	}

}

/**UART5 GPIO Configuration
PB12     ------> UART5_RX
PB13     ------> UART5_TX
 */
void HAL_UART_MspInit(UART_HandleTypeDef* huart)
{
	GPIO_InitTypeDef GPIO_InitStruct = {0};
	if(huart->Instance==UART5)
	{
		__HAL_RCC_UART5_CLK_ENABLE();
		__HAL_RCC_GPIOB_CLK_ENABLE();
		GPIO_InitStruct.Pin = GPIO_PIN_12|GPIO_PIN_13;
		GPIO_InitStruct.Mode = GPIO_MODE_AF_PP;
		GPIO_InitStruct.Pull = GPIO_NOPULL;
		GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_LOW;
		GPIO_InitStruct.Alternate = GPIO_AF14_UART5;
		HAL_GPIO_Init(GPIOB, &GPIO_InitStruct);
		HAL_NVIC_SetPriority(UART5_IRQn, 0, 0);
		HAL_NVIC_EnableIRQ(UART5_IRQn);
	}

}


/**UART5 GPIO Configuration
PB12     ------> UART5_RX
PB13     ------> UART5_TX
 */
void HAL_UART_MspDeInit(UART_HandleTypeDef* huart)
{
	if(huart->Instance==UART5)
	{
		__HAL_RCC_UART5_CLK_DISABLE();
		HAL_GPIO_DeInit(GPIOB, GPIO_PIN_12|GPIO_PIN_13);
		HAL_NVIC_DisableIRQ(UART5_IRQn);
	}

}



void UART5_IRQHandler(void)
{
	HAL_UART_IRQHandler(&huart5);
}
