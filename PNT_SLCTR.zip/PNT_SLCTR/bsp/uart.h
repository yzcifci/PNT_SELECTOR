/*
 * uart.h
 *
 *  Created on: 10 ?ub 2020
 *      Author: yzcifci
 */

#ifndef UART_H_
#define UART_H_

/*
 * uart.c
 *
 *  Created on: 10 ?ub 2020
 *      Author: yzcifci
 */



#include "bspErrorHandler.h"

#define UART_BUFF_SIZE		64



void uartInit();
void uartHeadPlusPlus();
void uartReceiveCallBack(struct __UART_HandleTypeDef *huart);
uint16_t getUartEmptyBufferSize();
uint16_t getUartFilledBufferSize();
void uartTransmitData(uint8_t* data, uint32_t length);
void testUart();
void HAL_UART_MspInit(UART_HandleTypeDef* huart);
void HAL_UART_MspDeInit(UART_HandleTypeDef* huart);
void UART5_IRQHandler(void);



#endif /* UART_H_ */
